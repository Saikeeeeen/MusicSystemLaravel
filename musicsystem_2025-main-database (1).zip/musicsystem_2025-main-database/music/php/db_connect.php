<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "musicsystem_2025";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  error_log("Connection failed: " . $conn->connect_error);
  die("An error occurred while connecting to the database. Please try again later.");
}
?>