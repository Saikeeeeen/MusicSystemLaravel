import React, { useEffect, useState, useMemo } from 'react';
import styles from './ui_css/InventoryPage.module.css';
import './ui_css/ManageEquipment.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit } from '@fortawesome/free-solid-svg-icons';
import { PaginationControl } from './ui/PaginationControl';
import EditInstrumentModal from './modals/EditInstrumentModal';
import EditToolModal from './modals/EditToolModal';
import ImageModal from './modals/ImageModal';

interface InventoryItem {
  instrument_id: number;
  instrument_no: number;
  instrument_type: string;
  status: string;
  barcode: string | null;
  brand: string | null;
  description: string | null;
  image_url: string | null;
  item_category: string;
}

const PlaceholderIcon = (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="equipment-placeholder">
    <path strokeLinecap="round" strokeLinejoin="round" d="m2.25 15.75 5.159-5.159a2.25 2.25 0 0 1 3.182 0l5.159 5.159m-1.5-1.5 1.409-1.409a2.25 2.25 0 0 1 3.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 0 0 1.5-1.5V6a1.5 1.5 0 0 0-1.5-1.5H3.75A1.5 1.5 0 0 0 2.25 6v12a1.5 1.5 0 0 0 1.5 1.5Zm10.5-11.25h.008v.008h-.008V8.25Zm.158 0a.225.225 0 1 1-.45 0 .225.225 0 0 1 .45 0Z" />
  </svg>
);

const ManageEquipment: React.FC = () => {
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isEditToolModalOpen, setIsEditToolModalOpen] = useState(false);
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);
  const [selectedImageUrl, setSelectedImageUrl] = useState('');

  const fetchInventory = () => {
    fetch('http://localhost:3001/api/inventory')
      .then((res) => res.json())
      .then((data) => {
        setInventory(data);
      })
      .catch((err) => console.error('Error fetching inventory:', err));
  };

  useEffect(() => {
    fetchInventory();
  }, []);

  const filteredInventory = useMemo(() => {
    let filtered = inventory;
    if (searchQuery) {
      const searchLower = searchQuery.toLowerCase();
      filtered = filtered.filter((item) => {
        return (
          item.instrument_no.toString().toLowerCase().includes(searchLower) ||
          item.instrument_type.toLowerCase().includes(searchLower) ||
          (item.barcode && item.barcode.toLowerCase().includes(searchLower))
        );
      });
    }
    return filtered;
  }, [inventory, searchQuery]);

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filteredInventory.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(filteredInventory.length / itemsPerPage);

  const openEditModal = (item: InventoryItem) => {
    setSelectedItem(item);
    if (item.item_category === 'instrument') {
      setIsEditModalOpen(true);
    } else {
      setIsEditToolModalOpen(true);
    }
  };

  const closeEditModal = () => {
    setSelectedItem(null);
    setIsEditModalOpen(false);
    setIsEditToolModalOpen(false);
  };

  const openImageModal = (imageUrl: string) => {
    setSelectedImageUrl(imageUrl);
    setIsImageModalOpen(true);
  };

  const closeImageModal = () => {
    setIsImageModalOpen(false);
    setSelectedImageUrl('');
  };

  const handleSuccess = () => {
    fetchInventory();
    closeEditModal();
  };

  return (
    <div className={`${styles.container} manage-equipment-container`}>
      <h1>Manage Equipment</h1>
      <p className={styles.description}>Edit details for all musical instruments and tools.</p>

      <input
        type="text"
        placeholder="Search..."
        className={styles.searchBox}
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
      />

      <div className={styles.tableContainer}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Image</th>
              <th>EQUIPMENT NO.</th>
              <th>EQUIPMENT</th>
              <th>CATEGORY</th>
              <th>BARCODE</th>
              <th>ACTIONS</th>
            </tr>
          </thead>
          <tbody>
            {currentItems.map((item) => (
              <tr key={`${item.item_category}-${item.instrument_id}`}>
                <td>
                  {item.image_url ? (
                    <img
                      src={`http://localhost:3001${item.image_url}`}
                      alt={item.instrument_type}
                      className="equipment-thumbnail"
                      onClick={() => openImageModal(`http://localhost:3001${item.image_url}`)}
                    />
                  ) : (
                    <div className="equipment-thumbnail placeholder-container">
                      {PlaceholderIcon}
                    </div>
                  )}
                </td>
                <td>{item.instrument_no}</td>
                <td>{item.instrument_type}</td>
                <td>{item.item_category}</td>
                <td>{item.barcode || '-'}</td>
                <td>
                  <FontAwesomeIcon icon={faEdit} className={styles.editIcon} onClick={() => openEditModal(item)} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <PaginationControl
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={setCurrentPage}
        />
      </div>

      {isEditModalOpen && selectedItem && (
        <EditInstrumentModal
          onClose={closeEditModal}
          onSuccess={handleSuccess}
          instrument={selectedItem}
        />
      )}

      {isEditToolModalOpen && selectedItem && (
        <EditToolModal
          onClose={closeEditModal}
          onSuccess={handleSuccess}
          tool={selectedItem}
        />
      )}

      {isImageModalOpen && (
        <ImageModal
          imageUrl={selectedImageUrl}
          onClose={closeImageModal}
        />
      )}
    </div>
  );
};

export default ManageEquipment;
