import React, { useState, useEffect, useMemo } from 'react';
import { Bar } from 'react-chartjs-2';
import * as XLSX from 'xlsx';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { format } from 'date-fns';
import DateTimeRangeModal from './modals/DateTimeRangeModal';
import './ui_css/ActivityLog.css'; // Reusing the same CSS for filters

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const cubicleColorMapping = {
  'Guitar': '#00C49F',
  'Piano': '#0088FE',
  'MTL': '#FFBB28',
};

const instrumentColorMapping = {
  'Guitar': '#00C49F',
  'Piano': '#0088FE',
  'Violin': '#FF8042',
};

const Reports = () => {
  const [data, setData] = useState([]);
  const [selectedTable, setSelectedTable] = useState('cubicles');
  const [cubicleType, setCubicleType] = useState('All');
  const [instrumentType, setInstrumentType] = useState('All');
  const [dateRange, setDateRange] = useState([
    {
      startDate: null,
      endDate: null,
      key: 'selection'
    }
  ]);
  const [startTime, setStartTime] = useState('00:00');
  const [endTime, setEndTime] = useState('23:59');
  const [showDateTimeModal, setShowDateTimeModal] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        let url = `http://localhost:3001/activity-log`;
        const params = new URLSearchParams();
        params.append('table', selectedTable);
        
        let type = 'All';
        if (selectedTable === 'cubicles') {
          type = cubicleType;
        } else if (selectedTable === 'instruments') {
          type = instrumentType;
        }
        params.append('type', type);

        if (dateRange[0].startDate && dateRange[0].endDate) {
          params.append('startDate', format(dateRange[0].startDate, 'yyyy-MM-dd'));
          params.append('endDate', format(dateRange[0].endDate, 'yyyy-MM-dd'));
        }
        params.append('startTime', startTime);
        params.append('endTime', endTime);
        url += `?${params.toString()}`;

        const response = await fetch(url);
        const result = await response.json();
        setData(result);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, [selectedTable, cubicleType, instrumentType, dateRange, startTime, endTime]);

  const handleApplyDateTimeFilter = (startDate, endDate, startT, endT) => {
    setDateRange([{ startDate, endDate, key: 'selection' }]);
    setStartTime(startT);
    setEndTime(endT);
    setShowDateTimeModal(false);
  };

  const chartData = useMemo(() => {
    if (!data || data.length === 0) {
      return {
        labels: [],
        datasets: [],
      };
    }

    let type = 'All';
    let colorMapping = {};
    if (selectedTable === 'cubicles') {
      type = cubicleType;
      colorMapping = cubicleColorMapping;
    } else if (selectedTable === 'instruments') {
      type = instrumentType;
      colorMapping = instrumentColorMapping;
    }

    const dataMap = data.reduce((acc, entry) => {
      let key;
      if (type === 'All') {
        key = entry.item_type;
      } else {
        if (selectedTable === 'cubicles') {
          key = `Cubicle ${entry.item_number}`;
        } else if (selectedTable === 'instruments') {
          key = `Instrument ${entry.item_number}`;
        }
      }
      
      if (!acc[key]) {
        acc[key] = 0;
      }
      acc[key]++;
      return acc;
    }, {});

    const labels = Object.keys(dataMap);
    const chartValues = Object.values(dataMap);
    
    let backgroundColors = [];
    if (type === 'All') {
      backgroundColors = labels.map(label => colorMapping[label] || '#CCCCCC');
    } else {
      const color = colorMapping[type] || '#CCCCCC';
      backgroundColors = labels.map(() => color);
    }

    return {
      labels,
      datasets: [
        {
          label: 'Number of Users',
          data: chartValues,
          backgroundColor: backgroundColors,
          borderColor: backgroundColors,
          borderWidth: 1,
        },
      ],
    };
  }, [data, selectedTable, cubicleType, instrumentType]);

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        display: false,
      },
      title: {
        display: true,
        text: 'Resource Usage Report',
        color: '#333',
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        title: {
          display: true,
          text: 'Number of Users',
          color: '#333',
        },
        ticks: {
          color: '#333',
        },
        grid: {
          display: false,
        },
        border: {
          display: true,
          color: '#333',
        },
      },
      x: {
        title: {
          display: true,
          text: 'Resource',
          color: '#333',
        },
        ticks: {
          color: '#333',
        },
        grid: {
          display: false,
        },
        border: {
          display: true,
          color: '#333',
        },
      },
    },
  };

  const handleExport = () => {
    const dataToExport = chartData.labels.map((label, index) => ({
      Resource: label,
      'Number of Users': chartData.datasets[0].data[index],
    }));

    const ws = XLSX.utils.json_to_sheet(dataToExport);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Report');
    XLSX.writeFile(wb, 'report.xlsx');
  };

  return (
    <div className="activity-log-container">
      {showDateTimeModal && (
        <DateTimeRangeModal
          initialDateRange={dateRange}
          initialStartTime={startTime}
          initialEndTime={endTime}
          onApply={handleApplyDateTimeFilter}
          onClose={() => setShowDateTimeModal(false)}
        />
      )}
      <h1>Reports</h1>
      <p className="description">Visualize resource usage with the filters below.</p>

      <section className="filters-box" aria-label="Filters">
        <div className="filters-header">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="size-6">
            <path d="M18.75 12.75h1.5a.75.75 0 0 0 0-1.5h-1.5a.75.75 0 0 0 0 1.5ZM12 6a.75.75 0 0 1 .75-.75h7.5a.75.75 0 0 1 0 1.5h-7.5A.75.75 0 0 1 12 6ZM12 18a.75.75 0 0 1 .75-.75h7.5a.75.75 0 0 1 0 1.5h-7.5A.75.75 0 0 1 12 18ZM3.75 6.75h1.5a.75.75 0 1 0 0-1.5h-1.5a.75.75 0 0 0 0 1.5ZM5.25 18.75h-1.5a.75.75 0 0 1 0-1.5h1.5a.75.75 0 0 1 0 1.5ZM3 12a.75.75 0 0 1 .75-.75h7.5a.75.75 0 0 1 0 1.5h-7.5A.75.75 0 0 1 3 12ZM9 3.75a2.25 2.25 0 1 0 0 4.5 2.25 2.25 0 0 0 0-4.5ZM12.75 12a2.25 2.25 0 1 1 4.5 0 2.25 2.25 0 0 1-4.5 0ZM9 15.75a2.25 2.25 0 1 0 0 4.5 2.25 2.25 0 0 0 0-4.5Z" />
          </svg>
          Filters:
        </div>
        <div className="filter-buttons" role="group" aria-label="Filter by resource type">
          <button type="button" onClick={() => setSelectedTable('cubicles')} className={selectedTable === 'cubicles' ? 'active' : ''}>Cubicles</button>
          <button type="button" onClick={() => setSelectedTable('instruments')} className={selectedTable === 'instruments' ? 'active' : ''}>Instruments</button>
        </div>
        <form className="filter-form" aria-label="Filter form">
          {selectedTable === 'cubicles' && (
            <div className="filter-group">
              <label htmlFor="cubicle-type">Cubicle type</label>
              <div className="custom-select-wrapper">
                <select id="cubicle-type" name="cubicle-type" className="custom-select" onChange={(e) => setCubicleType(e.target.value)} value={cubicleType}>
                  <option>All</option>
                  <option>Guitar</option>
                  <option>Piano</option>
                  <option>MTL</option>
                </select>
              </div>
            </div>
          )}
          {selectedTable === 'instruments' && (
            <div className="filter-group">
              <label htmlFor="instrument-type">Instrument type</label>
              <div className="custom-select-wrapper">
                <select id="instrument-type" name="instrument-type" className="custom-select" onChange={(e) => setInstrumentType(e.target.value)} value={instrumentType}>
                  <option>All</option>
                  <option>Guitar</option>
                  <option>Piano</option>
                  <option>Violin</option>
                </select>
              </div>
            </div>
          )}
          <div className="filter-group">
            <label htmlFor="date-time-range">Date & Time</label>
            <button type="button" className="date-time-filter-button-cubicle" onClick={() => setShowDateTimeModal(true)}>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="size-5">
                <path fillRule="evenodd" d="M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm.75-13a.75.75 0 0 0-1.5 0v5c0 .414.336.75.75.75h4a.75.75 0 0 0 0-1.5h-3.25V5Z" clipRule="evenodd" />
              </svg>
              Select Date & Time
            </button>
          </div>
        </form>
      </section>

      <section className="chart-section" aria-label="Usage chart">
        <Bar data={chartData} options={chartOptions} />
      </section>

      <section className="export-section">
        <button className="export-button" onClick={handleExport}>Print to Excel</button>
      </section>
    </div>
  );
};

export default Reports;
