
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './../ui_css/Login.css';
import musicpic from '/musicpic.png';
import LoginSuccessModal from '../modals/LoginSuccessModal';
import LoginFailureModal from '../modals/LoginFailureModal';
import { useAuth } from './AuthProvider';

// This interface should ideally be shared from AuthProvider, but defining it here is fine.
interface User {
  id: string;
  name: string;
  email: string;
}

const Login: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [showFailureModal, setShowFailureModal] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [pendingUser, setPendingUser] = useState<User | null>(null);

  const navigate = useNavigate();
  // Get both login and completeLogin from the auth context
  const { login, completeLogin } = useAuth();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    try {
      // 1. Call the login API and get user data, but don't set global state yet.
      const user = await login({ email, password });
      // 2. Store the user data locally and show the success modal.
      setPendingUser(user);
      setShowSuccessModal(true);
    } catch (err) {
      console.error('Login error:', err);
      setError('Invalid email or password. Please try again.');
      setShowFailureModal(true);
    }
  };

  const handleSuccessModalClose = () => {
    setShowSuccessModal(false);
    if (pendingUser) {
      // 3. Now that the modal is closed, set the global user state.
      completeLogin(pendingUser);
      // 4. Navigate to the dashboard.
      navigate('/dashboard');
    }
  };

  const handleFailureModalClose = () => {
    setShowFailureModal(false);
    setError('');
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  return (
    <div className="login-page-wrapper">
      {showSuccessModal && <LoginSuccessModal onClose={handleSuccessModalClose} />}
      {showFailureModal && <LoginFailureModal onClose={handleFailureModalClose} errorMessage={error} />}

      <header className="header">
        <div className="header-content">
          <div className="logo">
            <img src={musicpic} alt="College of Music Logo" />
          </div>
          <div className="title">
            <h1>College of Music System</h1>
            <p>A Digital Solution for Efficient Record-Keeping in College of Music</p>
          </div>
        </div>
      </header>

      <div className="login-card">
        <div className="left-side">
          <h2>Hello, Welcome!</h2>
          <p>Ready to manage your music recordsssss?</p>
        </div>
        <div className="right-side">
          <h2>LOGIN</h2>
          <form onSubmit={handleLogin}>
            <div className="input-group">
              <label htmlFor="username"><i className="fas fa-at"></i></label>
              <input type="text" id="username" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Username or Email" required />
            </div>
            <div className="input-group">
              <label htmlFor="password"><i className="fas fa-lock"></i></label>
              <input type={showPassword ? 'text' : 'password'} id="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" required />
              <i className={`fas ${showPassword ? 'fa-eye-slash' : 'fa-eye'} toggle-password`} id="togglePassword" onClick={togglePasswordVisibility}></i>
            </div>
            <a href="#" className="forgot-password">Forgot Password?</a>
            <button type="submit" className="login-btn">Login</button>
          </form>
        </div>
      </div>

      <footer className="footer"></footer>
    </div>
  );
};

export default Login;
