
import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from './AuthProvider';

const ProtectedRoute = ({ children }: { children: JSX.Element }) => {
  const { user, isLoading } = useAuth();

  // While the session is being verified, don't render anything.
  // You could render a loading spinner here instead.
  if (isLoading) {
    return null;
  }

  // If verification is complete and there's no user, redirect to login.
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // If there is a user, render the requested component.
  return children;
};

export default ProtectedRoute;
