import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import axios from 'axios';

// Define the shape of the user object and the auth context
interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  profile_picture_path: string | null;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (credentials: object) => Promise<User>; // Now returns the user
  completeLogin: (user: User) => void; // New function to set the user state
  logout: () => Promise<void>;
  updateUserProfile: (userData: User) => void; // New function to update user profile
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const API_URL = 'http://localhost:3001/api';

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const verifySession = async () => {
      try {
        const response = await axios.get(`${API_URL}/verify-session`, {
          withCredentials: true,
        });
        setUser(response.data);
      } catch (error) {
        console.log('No active session or session expired.');
        setUser(null);
      } finally {
        setIsLoading(false);
      }
    };

    verifySession();
  }, []);

  // This function now just performs the API call and returns the user data on success.
  const login = async (credentials: object): Promise<User> => {
    try {
      const response = await axios.post(`${API_URL}/login`, credentials, {
        withCredentials: true,
      });
      return response.data;
    } catch (error) {
      console.error('Login failed:', error);
      throw error; // Re-throw to be handled by the Login component
    }
  };

  // This new function will be called by the Login component AFTER the success modal.
  const completeLogin = (userToSet: User) => {
    setUser(userToSet);
  };

  const logout = async () => {
    try {
      await axios.post(`${API_URL}/logout`, {}, {
        withCredentials: true,
      });
      setUser(null);
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  const value = {
    user,
    isLoading,
    login,
    completeLogin, // Export the new function
    logout,
    updateUserProfile: (userData: User) => setUser(userData),
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
