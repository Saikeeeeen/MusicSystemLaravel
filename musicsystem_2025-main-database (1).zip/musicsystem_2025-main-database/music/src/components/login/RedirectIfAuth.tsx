import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from './AuthProvider';

const RedirectIfAuth = ({ children }: { children: JSX.Element }) => {
  const { user, isLoading } = useAuth();

  // While we check for a session, don't render anything
  if (isLoading) {
    return null;
  }

  // If the user is logged in, redirect them away from the login page
  if (user) {
    return <Navigate to="/dashboard" replace />;
  }

  // If there is no user, show the login page
  return children;
};

export default RedirectIfAuth;
