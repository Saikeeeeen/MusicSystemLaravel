import React, { useState, useEffect } from 'react';
import { format } from 'date-fns';
import '../ui_css/DateTimeRangeModal.css'; // Corrected path

interface DateTimeRangeModalProps {
  initialDateRange: { startDate: Date | null; endDate: Date | null; key: string }[];
  initialStartTime: string;
  initialEndTime: string;
  onApply: (startDate: Date | null, endDate: Date | null, startTime: string, endTime: string) => void;
  onClose: () => void;
}

const DateTimeRangeModal: React.FC<DateTimeRangeModalProps> = ({
  initialDateRange,
  initialStartTime,
  initialEndTime,
  onApply,
  onClose,
}) => {
  const [fromDate, setFromDate] = useState<string>(
    initialDateRange[0].startDate ? format(initialDateRange[0].startDate, 'yyyy-MM-dd') : ''
  );
  const [toDate, setToDate] = useState<string>(
    initialDateRange[0].endDate ? format(initialDateRange[0].endDate, 'yyyy-MM-dd') : ''
  );
  const [fromTime, setFromTime] = useState<string>(initialStartTime);
  const [toTime, setToTime] = useState<string>(initialEndTime);

  useEffect(() => {
    // Set default values if initialDateRange is empty or null
    if (!initialDateRange[0].startDate || !initialDateRange[0].endDate) {
      const now = new Date();
      const todayString = format(now, 'yyyy-MM-dd');
      setFromDate(todayString);
      setToDate(todayString); // Default to today for both start and end date
    }
    if (!initialStartTime || !initialEndTime) {
      const now = new Date();
      const currentTimeString = format(now, 'HH:mm');
      setFromTime(currentTimeString);
      setToTime(currentTimeString);
    }
  }, [initialDateRange, initialStartTime, initialEndTime]);

  const handleApply = () => {
    const selectedStartDate = fromDate ? new Date(fromDate) : null;
    const selectedEndDate = toDate ? new Date(toDate) : null;
    onApply(selectedStartDate, selectedEndDate, fromTime, toTime);
  };

  const handleShowAllData = () => {
    onApply(null, null, '00:00', '23:59'); // Pass null for dates and default times
    onClose(); // Close the modal
  };

  return (
    <div className="modal-overlay">
      <div className="date-time-picker-container">
        <h3>Select Date & Time Range</h3>

        <div className="inputs-wrapper">
          {/* "From" Date and Time Group */}
          <div className="date-group">
            <label htmlFor="from-date">From</label>
            <input
              type="date"
              id="from-date"
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
            />
            <input
              type="time"
              id="from-time"
              value={fromTime}
              onChange={(e) => setFromTime(e.target.value)}
            />
          </div>

          {/* "To" Date and Time Group */}
          <div className="date-group">
            <label htmlFor="to-date">To</label>
            <input
              type="date"
              id="to-date"
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
            />
            <input
              type="time"
              id="to-time"
              value={toTime}
              onChange={(e) => setToTime(e.target.value)}
            />
          </div>
        </div>

        <button className="btn-set-date" onClick={handleApply}>Set Date</button>
        <button className="btn-show-all-data" onClick={handleShowAllData}>Show All Data</button> {/* New button */}
        <button className="btn-close-modal" onClick={onClose}>Close</button>
      </div>
    </div>
  );
};

export default DateTimeRangeModal;
