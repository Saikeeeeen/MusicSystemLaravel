import React from 'react';
import '../ui_css/AddStudentSuccessModal.css';

interface AddStudentSuccessModalProps {
  onClose: () => void;
  studentDetails: {
    name: string;
    idNumber: string;
    yearSection: string;
    rfid: string;
  };
}

const AddStudentSuccessModal: React.FC<AddStudentSuccessModalProps> = ({ onClose, studentDetails }) => {

  return (
    <div className="modal-backdrop">
      <div className="success-receipt-card">
        <div className="success-icon-wrapper">
          <div className="success-icon-inner">&#10003;</div>
        </div>

        <p className="text-gray-500 text-lg">Successfully added!</p>
        <h1 className="text-3xl font-bold text-gray-800">{studentDetails.name}</h1>

        <hr className="success-divider" />

        <div className="success-details-grid">
          <div className="success-detail-item">
            <span className="label">Name</span>
            <span className="value">{studentDetails.name}</span>
          </div>
          <div className="success-detail-item">
            <span className="label">Id Number</span>
            <span className="value">{studentDetails.idNumber}</span>
          </div>
          <div className="success-detail-item">
            <span className="label">Year & Sec</span>
            <span className="value">{studentDetails.yearSection}</span>
          </div>

          <div className="relative pt-4">
                 <div className="dashed-line"></div>
          </div>
          <div className="success-detail-item">
            <span className="label">RFID</span>
            <span className="value">{studentDetails.rfid}</span>
          </div>
        </div>

        <button className="success-btn-confirm" onClick={onClose}>CONFIRM</button>
      </div>
    </div>
  );

};

export default AddStudentSuccessModal;