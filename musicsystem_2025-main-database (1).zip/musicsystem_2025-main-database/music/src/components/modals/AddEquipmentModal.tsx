import { useState } from 'react';
import '../ui_css/AddEquipmentModal.css';
import GenericSuccessModal from './GenericSuccessModal';
import GenericFailureModal from './GenericFailureModal';
import ConfirmationModal from './ConfirmationModal';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUpload } from '@fortawesome/free-solid-svg-icons';

interface AddEquipmentModalProps {
  onClose: () => void;
  onSuccess: () => void;
}

const AddEquipmentModal = ({ onClose, onSuccess }: AddEquipmentModalProps) => {
  const [equipmentNo, setEquipmentNo] = useState('');
  const [equipmentType, setEquipmentType] = useState('');
  const [category, setCategory] = useState('instrument');
  const [brand, setBrand] = useState('');
  const [barcode, setBarcode] = useState('');
  const [description, setDescription] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [resultModalType, setResultModalType] = useState<'none' | 'success' | 'failure'>('none');
  const [errorMessage, setErrorMessage] = useState('');
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setImageFile(e.target.files[0]);
    }
  };

  const handleAddClick = () => {
    setIsConfirmationOpen(true);
  };

  const handleConfirm = async () => {
    setIsConfirmationOpen(false);
    const formData = new FormData();
    formData.append(category === 'instrument' ? 'instrument_no' : 'tool_no', equipmentNo);
    formData.append(category === 'instrument' ? 'instrument_type' : 'tool_type', equipmentType);
    formData.append('brand', brand);
    formData.append('barcode', barcode);
    formData.append('description', description);
    if (imageFile) {
      formData.append('image', imageFile);
    }

    const endpoint = category === 'instrument' ? 'http://localhost:3001/api/instruments' : 'http://localhost:3001/api/tools';

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        setResultModalType('success');
      } else {
        const contentType = response.headers.get("content-type");
        if (contentType && contentType.indexOf("application/json") !== -1) {
          const data = await response.json();
          setErrorMessage(data.message || 'Failed to add equipment.');
        } else {
          const text = await response.text();
          setErrorMessage(text || 'Failed to add equipment.');
        }
        setResultModalType('failure');
      }
    } catch (error: any) {
      setErrorMessage(error.message || 'An error occurred during submission.');
      setResultModalType('failure');
    }
  };

  const handleSuccessAndClose = () => {
    onSuccess();
    onClose();
  };

  const handleCloseResultModals = () => {
    setResultModalType('none');
    onClose();
  };

  return (
    <div className="add-equipment-modal-backdrop">
      {resultModalType === 'none' && !isConfirmationOpen && (
        <div className="add-equipment-modal-container">
          <div className="add-equipment-modal-header">
            <h2>Add New Equipment</h2>
          </div>
          <div className="add-equipment-modal-body">
            <div className="add-equipment-form-group">
              <label htmlFor="category">Category</label>
              <select id="category" value={category} onChange={(e) => setCategory(e.target.value)}>
                <option value="instrument">Instrument</option>
                <option value="tool">Tool</option>
              </select>
            </div>
            <div className="add-equipment-form-group">
              <label htmlFor="equipment-no">Equipment No.</label>
              <input type="text" id="equipment-no" value={equipmentNo} onChange={(e) => setEquipmentNo(e.target.value)} />
            </div>
            <div className="add-equipment-form-group">
              <label htmlFor="equipment-type">Equipment Type</label>
              <input type="text" id="equipment-type" value={equipmentType} onChange={(e) => setEquipmentType(e.target.value)} />
            </div>
            <div className="add-equipment-form-group">
              <label htmlFor="brand">Brand</label>
              <input type="text" id="brand" value={brand} onChange={(e) => setBrand(e.target.value)} />
            </div>
            <div className="add-equipment-form-group">
              <label htmlFor="barcode">Barcode</label>
              <input type="text" id="barcode" value={barcode} onChange={(e) => setBarcode(e.target.value)} />
            </div>
            <div className="add-equipment-form-group full-width">
              <label htmlFor="description">Description</label>
              <textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} />
            </div>
            <div className="add-equipment-form-group full-width">
              <label htmlFor="image-upload" className="upload-label">
                <FontAwesomeIcon icon={faUpload} />
                <span>Upload Photo</span>
              </label>
              <input type="file" id="image-upload" onChange={handleImageChange} style={{ display: 'none' }} />
              {imageFile && <span className="file-name">{imageFile.name}</span>}
            </div>
          </div>
          <div className="add-equipment-modal-footer">
            <button className="add-equipment-btn add-equipment-btn-secondary" onClick={onClose}>Cancel</button>
            <button className="add-equipment-btn add-equipment-btn-primary" onClick={handleAddClick}>Add Equipment</button>
          </div>
        </div>
      )}

      {isConfirmationOpen && (
        <ConfirmationModal
          title="Confirm Add Equipment"
          message="Are you sure you want to add this equipment?"
          onConfirm={handleConfirm}
          onClose={() => setIsConfirmationOpen(false)}
        />
      )}

      {resultModalType === 'success' && (
        <GenericSuccessModal onClose={handleSuccessAndClose} message="Equipment added successfully!" />
      )}

      {resultModalType === 'failure' && (
        <GenericFailureModal onClose={handleCloseResultModals} message={errorMessage} />
      )}
    </div>
  );
};

export default AddEquipmentModal;
