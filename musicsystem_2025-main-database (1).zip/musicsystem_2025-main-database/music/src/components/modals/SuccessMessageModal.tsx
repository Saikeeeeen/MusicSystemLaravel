import React from 'react';
import '../ui_css/SuccessMessageModal.css';

interface SuccessMessageModalProps {
  message: string;
  onClose: () => void;
}

const SuccessMessageModal: React.FC<SuccessMessageModalProps> = ({ message, onClose }) => {
  return (
    <div className="modal-backdrop">
      <div className="success-message-card">
        <div className="success-icon-wrapper">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="size-6">
            <path fillRule="evenodd" d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12Zm13.36-1.814a.75.75 0 1 0-1.22-1.09L11.697 12.5l-1.88-1.88a.75.75 0 1 0-1.06 1.06l2.5 2.5a.75.75 0 0 0 1.06 0l3-3Z" clipRule="evenodd" />
          </svg>
        </div>
        <h2>Success!</h2>
        <p className="subtitle">{message}</p>
        <button className="btn-close" onClick={onClose}>Close</button>
      </div>
    </div>
  );
};

export default SuccessMessageModal;