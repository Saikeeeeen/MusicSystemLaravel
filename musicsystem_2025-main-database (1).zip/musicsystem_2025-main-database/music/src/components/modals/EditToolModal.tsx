import { useState } from 'react';
import './../ui_css/EditInstrumentModal.css';
import GenericSuccessModal from './GenericSuccessModal';
import GenericFailureModal from './GenericFailureModal';
import ConfirmationModal from './ConfirmationModal';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUpload } from '@fortawesome/free-solid-svg-icons';

interface ToolItem {
    instrument_id: number;
    instrument_no: number;
    instrument_type: string;
    status: string;
    barcode: string | null;
    brand: string | null;
    description: string | null;
    image_url: string | null;
}

interface EditToolModalProps {
  onClose: () => void;
  onSuccess: () => void;
  tool: ToolItem;
}

const EditToolModal = ({ onClose, onSuccess, tool }: EditToolModalProps) => {
  const [toolNo, setToolNo] = useState(String(tool.instrument_no));
  const [toolType, setToolType] = useState(tool.instrument_type);
  const [brand, setBrand] = useState(tool.brand || '');
  const [barcode, setBarcode] = useState(tool.barcode || '');
  const [description, setDescription] = useState(tool.description || '');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [resultModalType, setResultModalType] = useState<'none' | 'success' | 'failure'>('none');
  const [errorMessage, setErrorMessage] = useState('');
  const [isSaveConfirmationOpen, setIsSaveConfirmationOpen] = useState(false);
  const [isDecommissionConfirmationOpen, setIsDecommissionConfirmationOpen] = useState(false);
  const [isRepairConfirmationOpen, setIsRepairConfirmationOpen] = useState(false);
  const [isReturnConfirmationOpen, setIsReturnConfirmationOpen] = useState(false);
  const [isRecommissionConfirmationOpen, setIsRecommissionConfirmationOpen] = useState(false);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setImageFile(e.target.files[0]);
    }
  };

  const handleSaveClick = () => {
    setIsSaveConfirmationOpen(true);
  };

  const handleDecommissionClick = () => {
    setIsDecommissionConfirmationOpen(true);
  };

  const handleRecommissionClick = () => {
    setIsRecommissionConfirmationOpen(true);
  };

  const handleRepairClick = () => {
    setIsRepairConfirmationOpen(true);
  };

  const handleReturnClick = () => {
    setIsReturnConfirmationOpen(true);
  };

  const handleConfirmSave = async () => {
    setIsSaveConfirmationOpen(false);
    const formData = new FormData();
    formData.append('tool_no', toolNo);
    formData.append('tool_type', toolType);
    formData.append('brand', brand);
    formData.append('barcode', barcode);
    formData.append('description', description);
    // Status is not updated here
    if (imageFile) {
      formData.append('image', imageFile);
    }

    try {
      const response = await fetch(`http://localhost:3001/api/tools/${tool.instrument_id}`, {
        method: 'PUT',
        body: formData,
      });

      if (response.ok) {
        setResultModalType('success');
      } else {
        const contentType = response.headers.get("content-type");
        if (contentType && contentType.indexOf("application/json") !== -1) {
          const data = await response.json();
          setErrorMessage(data.message || 'Failed to update equipment.');
        } else {
          const text = await response.text();
          setErrorMessage(text || 'Failed to update equipment.');
        }
        setResultModalType('failure');
      }
    } catch (error: any) {
      setErrorMessage(error.message || 'An error occurred during submission.');
      setResultModalType('failure');
    }
  };

  const updateStatus = async (newStatus: string) => {
    try {
      const response = await fetch(`http://localhost:3001/api/tools/${tool.instrument_id}/status`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status: newStatus }),
      });

      if (response.ok) {
        setResultModalType('success');
      } else {
        const contentType = response.headers.get("content-type");
        if (contentType && contentType.indexOf("application/json") !== -1) {
          const data = await response.json();
          setErrorMessage(data.message || `Failed to update status to ${newStatus}.`);
        } else {
          const text = await response.text();
          setErrorMessage(text || `Failed to update status to ${newStatus}.`);
        }
        setResultModalType('failure');
      }
    } catch (error: any) {
      setErrorMessage(error.message || 'An error occurred during status update.');
      setResultModalType('failure');
    }
  };

  const handleConfirmDecommission = () => {
    setIsDecommissionConfirmationOpen(false);
    updateStatus('Decommissioned');
  };

  const handleConfirmRecommission = () => {
    setIsRecommissionConfirmationOpen(false);
    updateStatus('Available');
  };

  const handleConfirmRepair = () => {
    setIsRepairConfirmationOpen(false);
    updateStatus('Under Repair');
  };

  const handleConfirmReturn = () => {
    setIsReturnConfirmationOpen(false);
    updateStatus('Available');
  };

  const handleSuccessAndClose = () => {
    onSuccess();
    onClose();
  };

  const handleCloseResultModals = () => {
    setResultModalType('none');
    onClose();
  };

  return (
    <div className="edit-instrument-modal-backdrop">
      {resultModalType === 'none' && !isSaveConfirmationOpen && !isDecommissionConfirmationOpen && !isRepairConfirmationOpen && !isReturnConfirmationOpen && !isRecommissionConfirmationOpen && (
        <div className="edit-instrument-modal-container">
          <div className="edit-instrument-modal-header">
            <h2>Edit Equipment</h2>
          </div>
          <div className="edit-instrument-modal-body">
            <div className="edit-instrument-form-group">
              <label htmlFor="tool-no">Equipment No.</label>
              <input type="text" id="tool-no" value={toolNo} onChange={(e) => setToolNo(e.target.value)} />
            </div>
            <div className="edit-instrument-form-group">
              <label htmlFor="tool-type">Equipment Type</label>
              <input type="text" id="tool-type" value={toolType} onChange={(e) => setToolType(e.target.value)} />
            </div>
            <div className="edit-instrument-form-group">
              <label htmlFor="brand">Brand</label>
              <input type="text" id="brand" value={brand} onChange={(e) => setBrand(e.target.value)} />
            </div>
            <div className="edit-instrument-form-group">
              <label htmlFor="barcode">Barcode</label>
              <input type="text" id="barcode" value={barcode} onChange={(e) => setBarcode(e.target.value)} />
            </div>
            <div className="edit-instrument-form-group full-width">
              <label htmlFor="description">Description</label>
              <textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} />
            </div>
            <div className="edit-instrument-form-group full-width">
              <label htmlFor="image-upload" className="upload-label">
                <FontAwesomeIcon icon={faUpload} />
                <span>Upload Photo</span>
              </label>
              <input type="file" id="image-upload" onChange={handleImageChange} style={{ display: 'none' }} />
              {imageFile && <span className="file-name">{imageFile.name}</span>}
            </div>
          </div>
          <div className="edit-instrument-modal-footer">
            {tool.status === 'Decommissioned' ? (
              <button className="edit-instrument-btn edit-instrument-btn-recommission" onClick={handleRecommissionClick}>Recommission</button>
            ) : (
              <button className="edit-instrument-btn edit-instrument-btn-decommission" onClick={handleDecommissionClick}>Decommission</button>
            )}
            {tool.status === 'Under Repair' ? (
              <button className="edit-instrument-btn edit-instrument-btn-return" onClick={handleReturnClick}>Return from Repair</button>
            ) : (
              <button className="edit-instrument-btn edit-instrument-btn-repair" onClick={handleRepairClick}>Send for Repair</button>
            )}
            <div className="modal-buttons-group">
                <button className="edit-instrument-btn edit-instrument-btn-secondary edit-instrument-btn-small" onClick={onClose}>Cancel</button>
                <button className="edit-instrument-btn edit-instrument-btn-primary edit-instrument-btn-small" onClick={handleSaveClick}>Save Changes</button>
            </div>
          </div>
        </div>
      )}

      {isSaveConfirmationOpen && (
        <ConfirmationModal
          title="Confirm Save"
          message="Are you sure you want to save these changes?"
          onConfirm={handleConfirmSave}
          onClose={() => setIsSaveConfirmationOpen(false)}
        />
      )}

      {isDecommissionConfirmationOpen && (
        <ConfirmationModal
          title="Confirm Decommission"
          message="Are you sure you want to decommission this equipment? This action cannot be undone."
          onConfirm={handleConfirmDecommission}
          onClose={() => setIsDecommissionConfirmationOpen(false)}
        />
      )}

      {isRecommissionConfirmationOpen && (
        <ConfirmationModal
          title="Confirm Recommission"
          message="Are you sure you want to put this equipment back into service?"
          onConfirm={handleConfirmRecommission}
          onClose={() => setIsRecommissionConfirmationOpen(false)}
        />
      )}

      {isRepairConfirmationOpen && (
        <ConfirmationModal
          title="Confirm Repair"
          message="Are you sure you want to send this equipment for repair?"
          onConfirm={handleConfirmRepair}
          onClose={() => setIsRepairConfirmationOpen(false)}
        />
      )}

      {isReturnConfirmationOpen && (
        <ConfirmationModal
          title="Confirm Return"
          message="Are you sure you want to return this equipment from repair?"
          onConfirm={handleConfirmReturn}
          onClose={() => setIsReturnConfirmationOpen(false)}
        />
      )}

      {resultModalType === 'success' && (
        <GenericSuccessModal onClose={handleSuccessAndClose} message="Operation successful!" />
      )}

      {resultModalType === 'failure' && (
        <GenericFailureModal onClose={handleCloseResultModals} message={errorMessage} />
      )}
    </div>
  );
};

export default EditToolModal;