import { useState } from 'react';
import '../ui_css/AddStudentModal.css';
import AddStudentSuccessModal from './AddStudentSuccessModal';
import FailureModal from './FailureModal';

interface AddStudentModalProps {
  onClose: () => void;
}

interface StudentResult {
  reference?: string;
  name: string;
  idNumber: string;
  cubicleType?: string;
  cubicleNo?: number;
  studentId?: string;
  availableTime?: string;
  errorMessage?: string;
  yearSection?: string;
  rfid?: string;
}

const AddStudentModal = ({ onClose }: AddStudentModalProps) => {
  const [step, setStep] = useState(1);
  const [rfid, setRfid] = useState('');
  const [studentId, setStudentId] = useState('');
  const [firstName, setFirstName] = useState('');
  const [middleInitial, setMiddleInitial] = useState('');
  const [lastName, setLastName] = useState('');
  const [year, setYear] = useState('');
  const [sec, setSec] = useState('');
  const [resultModalType, setResultModalType] = useState<'none' | 'success' | 'failure'>('none');
  const [studentResult, setStudentResult] = useState<StudentResult | null>(null);
  const [validationError, setValidationError] = useState<string | null>(null);

  const handleNext = () => {
    if (step === 1 && rfid && studentId) {
      setStep(2);
    } else if (step === 2 && firstName && lastName && year && sec) {
      setStep(3);
    }
  };

  const handleBack = () => {
    setStep(step - 1);
  };

  const handleSubmit = async () => {
    setValidationError(null);
    const studentData = {
      rfid_uid: rfid,
      student_id: studentId,
      first_name: firstName,
      middle_initial: middleInitial,
      last_name: lastName,
      year: parseInt(year),
      sec: sec,
    };

    try {
      const response = await fetch('http://localhost:3001/api/students', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(studentData),
      });

      const data = await response.json();

      if (response.ok) {
        setStudentResult({
          reference: data.id, // Assuming the backend returns an 'id' for the new student
          name: `${firstName} ${lastName}`,
          idNumber: studentId,
          yearSection: `${year}-${sec}`,
          rfid: rfid,
        });
        setResultModalType('success');
      } else {
        setStudentResult({
          studentId: studentId,
          name: `${firstName} ${lastName}`,
          availableTime: 'N/A', // Not applicable for student addition
          errorMessage: data.message || 'Unknown error',
        });
        setValidationError(data.message || 'Unknown error');
        setResultModalType('failure');
      }
    } catch (error: any) {
      console.error('Error submitting student data:', error);
      setValidationError(error.message || 'An error occurred during submission.');
      setResultModalType('failure');
    }
  };

  const handleCloseResultModals = () => {
    setStep(1);
    setRfid('');
    setStudentId('');
    setFirstName('');
    setMiddleInitial('');
    setLastName('');
    setYear('');
    setSec('');
    setStudentResult(null);
    setResultModalType('none');
    onClose(); // Close the main AddStudentModal
  };

  const getProgressWidth = () => {
    const totalSteps = 3;
    return ((step - 1) / (totalSteps - 1)) * 100;
  };

  const renderStepContent = () => {
    switch (step) {
      case 1:
        return (
          <div id="step-1" className={`modal-step ${step === 1 ? 'active' : ''}`}>
            <div className="form-group">
              <label htmlFor="rfid">RFID</label>
              <input type="text" id="rfid" placeholder="Tap your ID" value={rfid} onChange={(e) => setRfid(e.target.value)} />
            </div>
            <div className="form-group">
              <label htmlFor="student-id">Student ID</label>
              <input type="text" id="student-id" placeholder="Enter your student ID" value={studentId} onChange={(e) => setStudentId(e.target.value)} />
            </div>
            {validationError && <p style={{ color: 'red' }}>{validationError}</p>}
          </div>
        );
      case 2:
        return (
          <div id="step-2" className={`modal-step ${step === 2 ? 'active' : ''}`}>
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="first-name">First Name</label>
                <input type="text" id="first-name" placeholder="Enter your first name" value={firstName} onChange={(e) => setFirstName(e.target.value)} />
              </div>
              <div className="form-group">
                <label htmlFor="middle-initial">Middle Initial</label>
                <input type="text" id="middle-initial" placeholder="Enter middle initial (optional)" value={middleInitial} onChange={(e) => setMiddleInitial(e.target.value)} maxLength={1} />
              </div>
              <div className="form-group">
                <label htmlFor="last-name">Last Name</label>
                <input type="text" id="last-name" placeholder="Enter your last name" value={lastName} onChange={(e) => setLastName(e.target.value)} />
              </div>
            </div>
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="year">Year</label>
                <input type="text" id="year" placeholder="e.g., 3" value={year} onChange={(e) => setYear(e.target.value)} />
              </div>
              <div className="form-group">
                <label htmlFor="section">Section</label>
                <input type="text" id="section" placeholder="e.g., A" value={sec} onChange={(e) => setSec(e.target.value)} />
              </div>
            </div>
          </div>
        );
      case 3:
        return (
          <div id="step-3" className={`modal-step ${step === 3 ? 'active' : ''}`}>
            <div className="review-section">
              <h4>STUDENT INFORMATION:</h4>
              <div className="review-info">
                <p><span className="label">RFID:</span><span className="value">{rfid}</span></p>
                <p><span className="label">Student ID:</span><span className="value">{studentId}</span></p>
                <p><span className="label">First Name:</span><span className="value">{firstName}</span></p>
                <p><span className="label">Middle Initial:</span><span className="value">{middleInitial}</span></p>
                <p><span className="label">Last Name:</span><span className="value">{lastName}</span></p>
                <p><span className="label">Year:</span><span className="value">{year}</span></p>
                <p><span className="label">Section:</span><span className="value">{sec}</span></p>
              </div>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="modal-backdrop">
      {resultModalType === 'none' && (
        <div className="modal-container">
          <div className="modal-header">
            <div className="stepper">
              <div className={`step ${step >= 1 ? 'completed' : ''} ${step === 1 ? 'active' : ''}`}>
                <div className="step-circle">{step > 1 ? '✓' : '1'}</div>
                <div className="step-label">Scan Identification</div>
              </div>
              <div className={`step ${step >= 2 ? 'completed' : ''} ${step === 2 ? 'active' : ''}`}>
                <div className="step-circle">{step > 2 ? '✓' : '2'}</div>
                <div className="step-label">Student Details</div>
              </div>
              <div className={`step ${step === 3 ? 'active' : ''}`}>
                <div className="step-circle">3</div>
                <div className="step-label">Review Student Info</div>
              </div>
            </div>
          </div>

          <div className="modal-body">
            {renderStepContent()}
          </div>

          <div className="modal-footer">
            <button className="btn btn-secondary" onClick={handleCloseResultModals}>Go Back</button>
            <div className="footer-buttons">
              {step > 1 && <button className="btn btn-secondary" onClick={handleBack}>Prev</button>}
              {step < 3 && <button className="btn btn-primary" onClick={handleNext} disabled={ (step === 1 && (!rfid || !studentId)) || (step === 2 && (!firstName || !lastName || !year || !sec))}>Next</button>}
              {step === 3 && <button className="btn btn-success" onClick={handleSubmit}>Done</button>}
            </div>
          </div>
        </div>
      )}

      {resultModalType === 'success' && studentResult && (
        <AddStudentSuccessModal onClose={handleCloseResultModals} studentDetails={studentResult} />
      )}

      {resultModalType === 'failure' && studentResult && (
        <FailureModal onClose={handleCloseResultModals} errorMessage={validationError || 'Failed to add student.'} studentDetails={studentResult} />
      )}
    </div>
  );
};

export default AddStudentModal;