import React from 'react';
import '../ui_css/ConfirmationModal.css';

interface ConfirmationModalProps {
  onClose: () => void;
  onConfirm: () => void;
  message: string;
  title: string;
}

const ConfirmationModal: React.FC<ConfirmationModalProps> = ({ onClose, onConfirm, message, title }) => {
  return (
    <div className="confirmation-modal-backdrop">
      <div className="confirmation-modal-container">
        <div className="confirmation-icon-wrapper">
          <div className="confirmation-icon-inner">!</div>
        </div>
        <h2>{title}</h2>
        <p>{message}</p>
        <div className="confirmation-button-group">
          <button className="confirmation-btn confirmation-btn-secondary" onClick={onClose}>Cancel</button>
          <button className="confirmation-btn confirmation-btn-primary" onClick={onConfirm}>Confirm</button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmationModal;