
import React from 'react';
import '../ui_css/LoginFailureModal.css';

interface LoginFailureModalProps {
  onClose: () => void;
  errorMessage: string;
}

const LoginFailureModal: React.FC<LoginFailureModalProps> = ({ onClose, errorMessage }) => {
  return (
    <div className="modal-backdrop">
      <div className="failure-receipt-card">
        <div className="failure-icon-wrapper">
          <div className="failure-icon-inner">!</div>
        </div>

        <h2>Login Failed!</h2>
        <p className="subtitle">{errorMessage}</p>

        <button className="failure-btn-confirm" onClick={onClose}>TRY AGAIN</button>
      </div>
    </div>
  );
};

export default LoginFailureModal;
