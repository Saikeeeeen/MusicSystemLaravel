import React from 'react';
import '../ui_css/GenericSuccessModal.css';

interface GenericSuccessModalProps {
  onClose: () => void;
  message: string;
}

const GenericSuccessModal: React.FC<GenericSuccessModalProps> = ({ onClose, message }) => {
  return (
    <div className="confirmation-modal-backdrop">
      <div className="confirmation-modal-container">
        <div className="confirmation-icon-wrapper success">
          <div className="success-icon-inner">&#10003;</div>
        </div>
        <h2>Success!</h2>
        <p>{message}</p>
        <div className="confirmation-button-group">
          <button className="confirmation-btn confirmation-btn-primary" onClick={onClose}>OK</button>
        </div>
      </div>
    </div>
  );
};

export default GenericSuccessModal;