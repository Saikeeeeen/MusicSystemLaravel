import React from 'react';
import '../ui_css/SuccessModal.css';

interface BookingDetails {
  reference: string;
  name: string;
  idNumber: string;
  cubicleType: string;
  cubicleNo: number;
}

interface TimeoutDetails {
  reference: string;
  name: string;
  room: string;
  timeIn: string;
  timeOut: string;
  duration: string;
}

interface SuccessModalProps {
  onClose: () => void;
  bookingDetails?: BookingDetails;
  timeoutDetails?: TimeoutDetails;
}

const SuccessModal: React.FC<SuccessModalProps> = ({ onClose, bookingDetails, timeoutDetails }) => {
  console.log('SuccessModal props:', { bookingDetails, timeoutDetails });

  if (bookingDetails) {
    return (
      <div className="modal-backdrop">
        <div className="success-receipt-card">
          <div className="success-icon-wrapper">
            <div className="success-icon-inner">&#10003;</div>
          </div>

          <h2>{bookingDetails.reference}</h2>
          <p className="subtitle">Booking reference</p>

          <hr className="success-divider" />

          <div className="success-details-grid">
            <div className="success-detail-item">
              <span className="label">Name</span>
              <span className="value">{bookingDetails.name}</span>
            </div>
            <div className="success-detail-item">
              <span className="label">Id Number</span>
              <span className="value">{bookingDetails.idNumber}</span>
            </div>
            <div className="success-detail-item">
              <span className="label">Cubicle Type</span>
              <span className="value">{bookingDetails.cubicleType}</span>
            </div>
            <div className="success-detail-item">
              <span className="label">Cubicle No.</span>
              <span className="value">{bookingDetails.cubicleNo}</span>
            </div>
          </div>

          <button className="success-btn-confirm" onClick={onClose}>CONFIRM</button>
        </div>
      </div>
    );
  }

  if (timeoutDetails) {
    return (
      <div className="modal-backdrop">
        <div className="success-receipt-card">
          <div className="success-icon-wrapper">
            <div className="success-icon-inner">&#10003;</div>
          </div>

          <h2>{timeoutDetails.reference}</h2>
          <p className="subtitle">Timeout reference</p>

          <hr className="success-divider" />

          <div className="success-details-grid">
            <div className="success-detail-item">
              <span className="label">Name</span>
              <span className="value">{timeoutDetails.name}</span>
            </div>
            <div className="success-detail-item">
              <span className="label">Room</span>
              <span className="value">{timeoutDetails.room}</span>
            </div>
            <div className="success-detail-item">
              <span className="label">Time In</span>
              <span className="value">{timeoutDetails.timeIn}</span>
            </div>
            <div className="success-detail-item">
              <span className="label">Time Out</span>
              <span className="value">{timeoutDetails.timeOut}</span>
            </div>
            <div className="success-detail-item">
              <span className="label">Duration</span>
              <span className="value">{timeoutDetails.duration}</span>
            </div>
          </div>

          <button className="success-btn-confirm" onClick={onClose}>CONFIRM</button>
        </div>
      </div>
    );
  }

  return null;
};

export default SuccessModal;