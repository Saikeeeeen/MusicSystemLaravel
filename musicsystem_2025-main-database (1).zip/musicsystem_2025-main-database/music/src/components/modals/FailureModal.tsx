import React from 'react';
import '../ui_css/FailureModal.css';

interface FailureModalProps {
  onClose: () => void;
  errorMessage: string;
  studentDetails: {
    studentId: string;
    name: string;
    availableTime: string;
  };
}

const FailureModal: React.FC<FailureModalProps> = ({ onClose, errorMessage, studentDetails }) => {
  return (
    <div className="modal-backdrop">
      <div className="failure-receipt-card">
        <div className="failure-icon-wrapper">
          <div className="failure-icon-inner">!</div>
        </div>

        <h2>Booking Failed!</h2>
        <p className="subtitle">{errorMessage}</p>

        <hr className="failure-divider" />

        <div className="failure-details-grid">
          <div className="failure-detail-item">
            <span className="label">Student ID</span>
            <span className="value">{studentDetails.studentId}</span>
          </div>
          <div className="failure-detail-item">
            <span className="label">Name</span>
            <span className="value">{studentDetails.name}</span>
          </div>
          <div className="failure-detail-item">
            <span className="label">Available Time</span>
            <span className="value">{studentDetails.availableTime}</span>
          </div>
        </div>

        <button className="failure-btn-confirm" onClick={onClose}>CONFIRM</button>
      </div>
    </div>
  );
};

export default FailureModal;