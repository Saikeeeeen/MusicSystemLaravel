import React from 'react';
import '../ui_css/AddUserModal.css';
import AddUserForm from '../AddUserForm';

interface AddUserModalProps {
  onClose: () => void;
  onUserAdded: (message: string, type: 'success' | 'error') => void;
}

const AddUserModal: React.FC<AddUserModalProps> = ({ onClose, onUserAdded }) => {
  const handleUserAddedAndClose = (message: string, type: 'success' | 'error') => {
    onUserAdded(message, type);
    onClose(); // Close the modal after user is added
  };

  return (
    <div className="modal-backdrop">
      <div className="modal-container add-user-modal-container">
        <div className="modal-header">
          <h2>Add New User</h2>
          <button className="close-button" onClick={onClose}>&times;</button>
        </div>
        <div className="modal-body">
          <AddUserForm onUserAdded={handleUserAddedAndClose} />
        </div>
      </div>
    </div>
  );
};

export default AddUserModal;
