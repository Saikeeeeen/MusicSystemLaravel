
import React from 'react';
import '../ui_css/LoginSuccessModal.css';

interface LoginSuccessModalProps {
  onClose: () => void;
}

const LoginSuccessModal: React.FC<LoginSuccessModalProps> = ({ onClose }) => {
  return (
    <div className="modal-backdrop">
      <div className="success-receipt-card">
        <div className="success-icon-wrapper">
          <div className="success-icon-inner">&#10003;</div>
        </div>

        <h2>Login Successful!</h2>
        <p className="subtitle">Welcome back!</p>

        <button className="success-btn-confirm" onClick={onClose}>CONTINUE</button>
      </div>
    </div>
  );
};

export default LoginSuccessModal;
