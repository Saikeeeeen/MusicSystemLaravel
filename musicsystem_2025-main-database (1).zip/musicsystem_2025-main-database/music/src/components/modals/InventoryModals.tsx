// src/components/InventoryModals.tsx
import React from 'react';
import styles from '../ui_css/InventoryPage.module.css';

interface BorrowFormData {
  studentId: string;
  idNumber: string;
  email: string;
  equipment: string;
  equipmentNo: string;
  date: string;
  time: string;
}

interface ConfirmationData {
  name: string;
  id: string;
  email: string;
  equipment: string;
  equipmentNo: string;
}

export const BorrowModal: React.FC<{
  isOpen: boolean;
  formData: BorrowFormData;
  onClose: () => void;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
  onScanRFID: () => void;
  onNext: () => void;
}> = ({ isOpen, formData, onClose, onChange, onScanRFID, onNext }) => {
  if (!isOpen) return null;
  return (
    <div className={styles['modal-overlay']}>
      <div className={styles['borrow-modal']}>
        <div className={styles['borrow-header']}>
          <button onClick={onClose} className={styles['go-back-btn']}>
            ← GO BACK
          </button>
          <h2 className={styles['borrow-title']}>BORROW INSTRUMENT</h2>
        </div>
        <div className={styles['student-info-section']}>
          <h3>STUDENT INFORMATION:</h3>
          <div className={styles['student-info-row']}>
            <div className={styles['student-id-box']}>
              <label htmlFor="studentId">STUDENT ID</label>
              <input
                type="text"
                id="studentId"
                value={formData.studentId}
                onChange={onChange}
                placeholder="Enter Student ID"
                className={styles['student-id-input']}
              />
            </div>
            <div className={styles['vertical-divider']}></div>
            <div className={styles['rfid-scanner']} onClick={onScanRFID}>
              <div className={styles['rfid-barcode-container']}>
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="#ff6692" strokeWidth="2">
                  <line x1="8" y1="16" x2="8" y2="48" />
                  <line x1="20" y1="16" x2="20" y2="48" />
                  <line x1="32" y1="16" x2="32" y2="48" />
                  <line x1="44" y1="16" x2="44" y2="48" />
                  <line x1="56" y1="16" x2="56" y2="48" />
                </svg>
              </div>
              <span className={styles['rfid-label']}>CLICK TO SCAN</span>
            </div>
          </div>
        </div>
        <div className={styles['borrowing-info-section']}>
          <h3>BORROWING INFORMATION:</h3>
          <div className={styles['borrowing-info-row']}>
            <div className={styles['form-group']}>
              <label htmlFor="equipment">SELECT EQUIPMENT</label>
              <select id="equipment" value={formData.equipment} onChange={onChange} className={styles['form-select']}>
                <option value="VIOLIN">VIOLIN</option>
                <option value="GUITAR">GUITAR</option>
                <option value="SPEAKER">SPEAKER</option>
              </select>
            </div>
            <div className={styles['form-group']}>
              <label htmlFor="date">DATE</label>
              <input type="date" id="date" value={formData.date} onChange={onChange} className={styles['form-input']} />
            </div>
            <div className={styles['form-group']}>
              <label htmlFor="time">TIME</label>
              <input type="time" id="time" value={formData.time} onChange={onChange} className={styles['form-input']} />
            </div>
          </div>
          <div className={styles['form-group']}>
            <label htmlFor="equipmentNo">SELECT EQUIPMENT NO.</label>
            <select id="equipmentNo" value={formData.equipmentNo} onChange={onChange} className={styles['form-select']}>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
            </select>
          </div>
        </div>
        <button onClick={onNext} className={styles['add-schedule-button']}>
          📅 Add a Schedule
        </button>
      </div>
    </div>
  );
};

export const SummaryModal: React.FC<{
  isOpen: boolean;
  formData: BorrowFormData;
  onClose: () => void;
  onConfirm: () => void;
}> = ({ isOpen, formData, onClose, onConfirm }) => {
  if (!isOpen) return null;
  return (
    <div className={styles['modal-overlay']}>
      <div className={styles['summary-modal']}>
        <div className={styles['summary-header']}>
          <button onClick={onClose} className={styles['go-back-btn']}>
            ← GO BACK
          </button>
          <h2 className={`${styles['modal-title']} text-center`}>BORROW SUMMARY</h2>
        </div>
        <div className={styles['student-info-section']}>
          <h3>STUDENT INFORMATION:</h3>
          <div className={styles['info-row']}><label>Name:</label><span>{formData.studentId || 'N/A'}</span></div>
          <div className={styles['info-row']}><label>ID Number:</label><span>{formData.idNumber || 'N/A'}</span></div>
          <div className={styles['info-row']}><label>Email:</label><span>{formData.email || 'N/A'}</span></div>
        </div>
        <div className={styles['borrowing-info-section']}>
          <h3>BORROW INFORMATION:</h3>
          <div className={styles['info-row']}><label>Equipment:</label><span>{formData.equipment}</span></div>
          <div className={styles['info-row']}><label>Equipment Number:</label><span>{formData.equipmentNo}</span></div>
          <div className={styles['info-row']}><label>Date:</label><span>{formData.date}</span></div>
          <div className={styles['info-row']}><label>Time:</label><span>{formData.time}</span></div>
        </div>
        <button onClick={onConfirm} className={styles['confirm-button']}>
          ✅ Confirm
        </button>
      </div>
    </div>
  );
};

export const ConfirmationModal: React.FC<{
  isOpen: boolean;
  confirmationData: ConfirmationData;
  onConfirm: () => void;
}> = ({ isOpen, confirmationData, onConfirm }) => {
  if (!isOpen) return null;
  return (
    <div className={styles['modal-overlay']}>
      <div className={styles['confirmation-modal']}>
        <h2 className={styles['confirmation-title']}>Borrow Confirmed</h2>
        <div className={styles['confirmation-details']}>
          <p><strong>Name:</strong> {confirmationData.name || 'N/A'}</p>
          <p><strong>ID:</strong> {confirmationData.id || 'N/A'}</p>
          <p><strong>Email:</strong> {confirmationData.email || 'N/A'}</p>
          <p><strong>Equipment:</strong> {confirmationData.equipment || 'N/A'}</p>
          <p><strong>Equipment No.:</strong> {confirmationData.equipmentNo || 'N/A'}</p>
        </div>
        <button onClick={onConfirm} className={styles['confirm-button']}>
          OK
        </button>
      </div>
    </div>
  );
};
