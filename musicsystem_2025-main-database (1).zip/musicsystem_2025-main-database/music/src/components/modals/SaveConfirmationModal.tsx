import React from 'react';
import '../ui_css/SaveConfirmationModal.css';

interface SaveConfirmationModalProps {
  onConfirm: () => void;
  onCancel: () => void;
}

const SaveConfirmationModal: React.FC<SaveConfirmationModalProps> = ({ onConfirm, onCancel }) => {
  return (
    <div className="modal-backdrop">
      <div className="save-confirmation-card">
        <div className="save-icon-wrapper">
          {/* Icon for save/check */}
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="size-6">
            <path fillRule="evenodd" d="M19.916 4.626a.75.75 0 0 1 .208 1.04l-9.75 10.5a.75.75 0 0 1-1.12.02L3.248 11.4a.75.75 0 1 1 1.004-1.12l4.154 3.724 9.15-9.853a.75.75 0 0 1 1.04-.208Z" clipRule="evenodd" />
          </svg>
        </div>

        <h2>Save Changes</h2>
        <p className="subtitle">Are you sure you want to save these changes?</p>

        <div className="save-buttons">
          <button className="save-btn-confirm" onClick={onConfirm}>Yes, Save</button>
          <button className="save-btn-cancel" onClick={onCancel}>Cancel</button>
        </div>
      </div>
    </div>
  );
};

export default SaveConfirmationModal;