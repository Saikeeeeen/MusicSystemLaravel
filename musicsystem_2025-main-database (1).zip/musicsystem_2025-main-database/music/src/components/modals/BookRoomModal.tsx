import { useState, useEffect } from 'react';
import SuccessModal from './SuccessModal';
import FailureModal from './FailureModal';
import '../ui_css/BookRoomModal.css';

interface Cubicle {
  cubicle_id: number;
  cubicle_type: string;
  cubicle_no: number;
}

interface AvailableCubicles {
  Guitar: Cubicle[];
  Piano: Cubicle[];
  MTL: Cubicle[];
}

interface StudentInfo {
  student_id: string;
  first_name: string;
  last_name: string;
  rfid_uid: string;
  mtl_time_remaining: number;
}

interface BookRoomModalProps {
  onClose: () => void;
}

const BookRoomModal = ({ onClose }: BookRoomModalProps) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [studentIdOrRfid, setStudentIdOrRfid] = useState('');
  const [studentInfo, setStudentInfo] = useState<StudentInfo | null>(null);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [availableCubicles, setAvailableCubicles] = useState<AvailableCubicles>({ Guitar: [], Piano: [], MTL: [] });
  const [selectedCubicleType, setSelectedCubicleType] = useState<string>('');
  const [selectedCubicleNumber, setSelectedCubicleNumber] = useState<number | string>('');
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [showFailureModal, setShowFailureModal] = useState(false);
  const [bookingResult, setBookingResult] = useState<any>(null);
  const [resultModalType, setResultModalType] = useState<'none' | 'success' | 'failure'>('none');

  useEffect(() => {
    const fetchAvailableCubicles = async () => {
      try {
        const response = await fetch('http://localhost:3001/api/available-cubicles');
        const data = await response.json();
        setAvailableCubicles(data);
      } catch (error) {
        console.error('Error fetching available cubicles:', error);
      }
    };

    fetchAvailableCubicles();
  }, []);

  const handleStudentIdValidation = async () => {
    setValidationError(null);
    try {
      const response = await fetch('http://localhost:3001/api/validate-student', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ studentIdOrRfid }),
      });

      const data = await response.json();

      if (response.ok) {
        setStudentInfo(data.student);
        setCurrentStep(2); // Move to booking details step
      } else {
        setValidationError(data.message || 'Student not found.');
      }
    } catch (error) {
      console.error('Error validating student:', error);
      setValidationError('An error occurred during validation.');
    }
  };

   const handleSubmitBooking = async () => {
    setValidationError(null); // Clear previous validation errors
    if (!studentInfo || !selectedCubicleNumber) {
      alert('Please complete all booking details.');
      return;
    }

    const selectedCubicleDetails = selectedCubicleType && selectedCubicleNumber
      ? availableCubicles[selectedCubicleType as keyof AvailableCubicles]?.find(
          (cubicle) => cubicle.cubicle_id === Number(selectedCubicleNumber)
        )
      : null;

    try {
      const response = await fetch('http://localhost:3001/api/book', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          cubicle_id: selectedCubicleNumber,
          student_id: studentInfo.student_id,
        }),
      });

      const data = await response.json();

      console.log('Response from server object:', response);
      console.log('Data from server object:', data);
      console.log('response.ok property:', response.ok);

      if (response.ok) {
        console.log('Entering success block...');
        setBookingResult({
          reference: data.booking_id, // Use booking_id as reference
          name: `${studentInfo.first_name} ${studentInfo.last_name}`,
          idNumber: studentInfo.student_id,
          cubicleType: selectedCubicleType,
          cubicleNo: selectedCubicleDetails?.cubicle_no,
        });
        setResultModalType('success');
        console.log('setResultModalType to success');
      } else {
        console.log('Entering failure block...');
        setBookingResult({
          studentId: studentInfo?.student_id || 'N/A',
          name: studentInfo ? `${studentInfo.first_name} ${studentInfo.last_name}` : 'N/A',
          availableTime: studentInfo?.mtl_time_remaining !== undefined ? `${studentInfo.mtl_time_remaining} hrs remaining` : 'N/A',
        });
        setValidationError(data.message || 'Unknown error');
        setResultModalType('failure');
        console.log('setResultModalType to failure');
      }
    } catch (error) {
      console.error('Error booking cubicle:', error);
      setValidationError('An error occurred during booking.');
      setResultModalType('failure');
      console.log('setResultModalType to failure (from catch block)');
    }
  };

  const handleNext = () => {
    if (currentStep === 1) {
      handleStudentIdValidation();
    } else if (currentStep === 2) {
      setCurrentStep(3);
    }
  };

  const handlePrev = () => {
    setCurrentStep(prev => prev - 1);
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div id="step-1" className="modal-step active">
            <div className="form-group">
              <label htmlFor="student-id-rfid">Student ID/RFID</label>
              <input
                type="text"
                id="student-id-rfid"
                placeholder="Enter ID or scan RFID"
                value={studentIdOrRfid}
                onChange={(e) => setStudentIdOrRfid(e.target.value)}
              />
            </div>
            {validationError && <p style={{ color: 'red' }}>{validationError}</p>}
          </div>
        );
      case 2:
        return (
          <div id="step-2" className="modal-step active">
            <div className="form-group">
              <label htmlFor="room-type">Select Room Type</label>
              <div className="select-wrapper">
                <select
                  id="room-type"
                  value={selectedCubicleType}
                  onChange={(e) => {
                    setSelectedCubicleType(e.target.value);
                    setSelectedCubicleNumber(''); // Reset room number when type changes
                  }}
                >
                  <option value="">Choose Practice Room Type</option>
                  {Object.keys(availableCubicles).map((type) => (
                    <option key={type} value={type}>
                      {type} Cubicle
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="room-no">Select Room No.</label>
              <div className="select-wrapper">
                <select
                  id="room-no"
                  value={selectedCubicleNumber}
                  onChange={(e) => setSelectedCubicleNumber(e.target.value)}
                  disabled={!selectedCubicleType}
                >
                  <option value="">Choose Room No.</option>
                  {selectedCubicleType &&
                    availableCubicles[selectedCubicleType as keyof AvailableCubicles]?.map((cubicle) => (
                      <option key={cubicle.cubicle_id} value={cubicle.cubicle_id}>
                        {cubicle.cubicle_no}
                      </option>
                    ))}
                </select>
              </div>
            </div>
          </div>
        );
      case 3:
        const selectedCubicleDetails = selectedCubicleType && selectedCubicleNumber
          ? availableCubicles[selectedCubicleType as keyof AvailableCubicles]?.find(
              (cubicle) => cubicle.cubicle_id === Number(selectedCubicleNumber)
            )
          : null;

        return (
          <div id="step-3" className="modal-step active">
            <div className="review-section">
              <h4>BOOKING INFORMATION:</h4>
              <div className="review-info">
                <p><span className="label">Name:</span><span className="value" id="review-name">{studentInfo?.first_name} {studentInfo?.last_name}</span></p>
                <p><span className="label">Room Type:</span><span className="value" id="review-room-type">{selectedCubicleDetails?.cubicle_type || 'N/A'}</span></p>
                <p><span className="label">Room Number:</span><span className="value" id="review-room-no">{selectedCubicleDetails?.cubicle_no || 'N/A'}</span></p>
                <p><span className="label">Student ID:</span><span className="value" id="review-student-id">{studentInfo?.student_id}</span></p>
              </div>
            </div>
            <div className="review-section">
              <h4>RFID INFORMATION:</h4>
              <div className="review-info">
                <p><span className="label">RFID:</span><span className="value" id="review-rfid">{studentInfo?.rfid_uid || 'N/A'}</span></p>
              </div>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  const getProgressWidth = () => {
    const totalSteps = 3;
    return ((currentStep - 1) / (totalSteps - 1)) * 100;
  };

  const handleCloseResultModals = () => {
    setCurrentStep(1);
    setStudentIdOrRfid('');
    setStudentInfo(null);
    setValidationError(null);
    setSelectedCubicleType('');
    setSelectedCubicleNumber('');
    setBookingResult(null);
    setResultModalType('none');
    onClose(); // Close the main BookRoomModal
  };

  return (
    <div className="modal-overlay">
      {console.log('Current resultModalType:', resultModalType)}
      {resultModalType === 'none' && (
        <div className="modal-content">
          <div className="modal-top-bar">
            <button className="go-back-btn" onClick={onClose}>
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="2.5" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" />
              </svg>
              GO BACK
            </button>
          </div>

          <div className="modal-header">
            <div className="stepper">
              <div className="stepper-line"><div className="stepper-progress" style={{ width: `${getProgressWidth()}%` }}></div></div>
              <div className={`step ${currentStep === 1 ? 'active' : currentStep > 1 ? 'completed' : ''}`} data-step="1">
                <div className="step-circle">{currentStep > 1 ? '✓' : '1'}</div>
                <div className="step-title">Scan Identification</div>
                <div className="step-description">Enter the student's RFID code and Student ID.</div>
              </div>
              <div className={`step ${currentStep === 2 ? 'active' : currentStep > 2 ? 'completed' : ''}`} data-step="2">
                <div className="step-circle">{currentStep > 2 ? '✓' : '2'}</div>
                <div className="step-title">Booking Details</div>
                <div className="step-description">Choose Room Type and Number to continue.</div>
              </div>
              <div className={`step ${currentStep === 3 ? 'active' : ''}`} data-step="3">
                <div className="step-circle">3</div>
                <div className="step-title">Review Student Info</div>
                <div className="step-description">Confirm all details before adding the student to the music system.</div>
              </div>
            </div>
          </div>

          <div className="modal-body">
            {renderStepContent()}
          </div>

          <div className="modal-actions">
            <button className={`btn btn-secondary ${currentStep === 1 ? 'hidden' : ''}`} onClick={handlePrev}>Prev</button>
            <button className={`btn btn-primary ${currentStep === 3 ? 'hidden' : ''}`} onClick={handleNext}>Next</button>
            <button className={`btn btn-success ${currentStep !== 3 ? 'hidden' : ''}`} onClick={handleSubmitBooking}>Done</button>
          </div>
        </div>
      )}

      {resultModalType === 'success' && bookingResult && (
        <SuccessModal onClose={handleCloseResultModals} bookingDetails={bookingResult} />
      )}

      {resultModalType === 'failure' && bookingResult && (
        <FailureModal onClose={handleCloseResultModals} errorMessage={validationError || 'Booking failed.'} studentDetails={bookingResult} />
      )}
    </div>
  );
};

export default BookRoomModal;