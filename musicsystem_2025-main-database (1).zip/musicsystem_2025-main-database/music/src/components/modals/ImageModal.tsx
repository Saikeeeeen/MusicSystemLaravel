import React from 'react';
import '../ui_css/ImageModal.css';

interface ImageModalProps {
  imageUrl: string;
  onClose: () => void;
}

const ImageModal: React.FC<ImageModalProps> = ({ imageUrl, onClose }) => {
  return (
    <div className="image-modal-backdrop" onClick={onClose}>
      <div className="image-modal-content" onClick={(e) => e.stopPropagation()}>
        <img src={imageUrl} alt="Enlarged equipment" />
        <button onClick={onClose} className="image-modal-close-btn">Close</button>
      </div>
    </div>
  );
};

export default ImageModal;
