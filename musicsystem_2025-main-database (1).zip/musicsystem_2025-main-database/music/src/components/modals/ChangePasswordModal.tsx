import React, { useState } from 'react';
import '../ui_css/ChangePasswordModal.css';

interface ChangePasswordModalProps {
  onClose: () => void;
  onPasswordChange: (currentPassword: string, newPassword: string) => Promise<void>;
}

const ChangePasswordModal: React.FC<ChangePasswordModalProps> = ({ onClose, onPasswordChange }) => {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmNewPassword, setShowConfirmNewPassword] = useState(false);

  const toggleShowCurrentPassword = () => setShowCurrentPassword(!showCurrentPassword);
  const toggleShowNewPassword = () => setShowNewPassword(!showNewPassword);
  const toggleShowConfirmNewPassword = () => setShowConfirmNewPassword(!showConfirmNewPassword);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage(null);

    if (newPassword !== confirmNewPassword) {
      setMessage({ type: 'error', text: 'New passwords do not match.' });
      return;
    }

    if (newPassword.length < 6) {
      setMessage({ type: 'error', text: 'New password must be at least 6 characters long.' });
      return;
    }

    try {
      await onPasswordChange(currentPassword, newPassword);
      // Success message will be handled by parent (Account.tsx) via a modal
      onClose(); // Close modal on success
    } catch (error: any) {
      setMessage({ type: 'error', text: error.message || 'Failed to change password.' });
    }
  };

  return (
    <div className="modal-backdrop">
      <div className="change-password-modal-card">
        <div class="logout-icon-wrapper">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-6">
  <path fill-rule="evenodd" d="M15.75 1.5a6.75 6.75 0 0 0-6.651 7.906c.067.39-.032.717-.221.906l-6.5 6.499a3 3 0 0 0-.878 2.121v2.818c0 .414.336.75.75.75H6a.75.75 0 0 0 .75-.75v-1.5h1.5A.75.75 0 0 0 9 19.5V18h1.5a.75.75 0 0 0 .53-.22l2.658-2.658c.19-.189.517-.288.906-.22A6.75 6.75 0 1 0 15.75 1.5Zm0 3a.75.75 0 0 0 0 1.5A2.25 2.25 0 0 1 18 8.25a.75.75 0 0 0 1.5 0 3.75 3.75 0 0 0-3.75-3.75Z" clip-rule="evenodd" />
</svg>
        </div>
        <h2>Change Password</h2>
        <p className="subtitle">Please enter your current and new password.</p>

        {message && (
          <div className={`message ${message.type}`}>
            {message.text}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="current-password">Current Password</label>
            <div className="password-input-wrapper">
              <input 
                type={showCurrentPassword ? 'text' : 'password'} 
                id="current-password" 
                value={currentPassword} 
                onChange={(e) => setCurrentPassword(e.target.value)} 
                required 
              />
              <i className={`fas ${showCurrentPassword ? 'fa-eye-slash' : 'fa-eye'} toggle-password`} onClick={toggleShowCurrentPassword}></i>
            </div>
          </div>
          <div className="form-group">
            <label htmlFor="new-password">New Password</label>
            <div className="password-input-wrapper">
              <input 
                type={showNewPassword ? 'text' : 'password'} 
                id="new-password" 
                value={newPassword} 
                onChange={(e) => setNewPassword(e.target.value)} 
                required 
              />
              <i className={`fas ${showNewPassword ? 'fa-eye-slash' : 'fa-eye'} toggle-password`} onClick={toggleShowNewPassword}></i>
            </div>
          </div>
          <div className="form-group">
            <label htmlFor="confirm-new-password">Confirm New Password</label>
            <div className="password-input-wrapper">
              <input 
                type={showConfirmNewPassword ? 'text' : 'password'} 
                id="confirm-new-password" 
                value={confirmNewPassword} 
                onChange={(e) => setConfirmNewPassword(e.target.value)} 
                required 
              />
              <i className={`fas ${showConfirmNewPassword ? 'fa-eye-slash' : 'fa-eye'} toggle-password`} onClick={toggleShowConfirmNewPassword}></i>
            </div>
          </div>

          <div className="modal-buttons">
            <button type="submit" className="btn-save">Save Changes</button>
            <button type="button" className="btn-cancel" onClick={onClose}>Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ChangePasswordModal;