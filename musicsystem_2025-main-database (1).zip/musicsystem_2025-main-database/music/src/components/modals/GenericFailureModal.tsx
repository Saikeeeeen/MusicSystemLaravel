import React from 'react';
import '../ui_css/GenericFailureModal.css';

interface GenericFailureModalProps {
  onClose: () => void;
  message: string;
}

const GenericFailureModal: React.FC<GenericFailureModalProps> = ({ onClose, message }) => {
  return (
    <div className="confirmation-modal-backdrop">
      <div className="confirmation-modal-container">
        <div className="confirmation-icon-wrapper failure">
          <div className="failure-icon-inner">!</div>
        </div>
        <h2>Failed!</h2>
        <p>{message}</p>
        <div className="confirmation-button-group">
          <button className="confirmation-btn confirmation-btn-primary" onClick={onClose}>OK</button>
        </div>
      </div>
    </div>
  );
};

export default GenericFailureModal;