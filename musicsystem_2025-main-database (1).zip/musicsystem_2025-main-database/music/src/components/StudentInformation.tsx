// Temporary comment to force re-compilation
import React, { useState, useEffect } from 'react';
import './ui_css/StudentInformation.css';
import AddStudentModal from './modals/AddStudentModal';
import ConfirmationModal from './modals/ConfirmationModal';

const StudentInformation = () => {
  const [selectedYear, setSelectedYear] = useState('All');
  const [selectedSection, setSelectedSection] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [studentData, setStudentData] = useState([]);
  const [allStudents, setAllStudents] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  const paginate = (data) => {
    if (!Array.isArray(data)) {
      console.error('Pagination data is not an array:', data);
      return []; // Return an empty array to prevent errors
    }
    const startIndex = (currentPage - 1) * itemsPerPage;
    return data.slice(startIndex, startIndex + itemsPerPage);
  };

  const fetchStudents = async () => {
    try {
      const response = await fetch(`http://localhost:3001/api/students?t=${new Date().getTime()}`);
      const data = await response.json();
      setAllStudents(data);
      setStudentData(data);
    } catch (error) {
      console.error('Error fetching students:', error);
    }
  };

  useEffect(() => {
    fetchStudents();
  }, []);

  

  useEffect(() => {
    let filteredData = allStudents.map(student => {
      const remainingHours = student.mtl_time_remaining / 60;
      let rowClass = '';
      if (remainingHours > 5) {
        rowClass = 'row-green';
      } else if (remainingHours > 2) {
        rowClass = 'row-yellow';
      } else {
        rowClass = 'row-red';
      }
      return { ...student, rowClass };
    });

    if (selectedYear !== 'All') {
      filteredData = filteredData.filter(student => student.year.toString() === selectedYear);
    }

    if (selectedSection !== 'All') {
      filteredData = filteredData.filter(student => student.sec === selectedSection);
    }

    if (searchQuery) {
      filteredData = filteredData.filter(student =>
        `${student.first_name} ${student.last_name}`.toLowerCase().includes(searchQuery.toLowerCase()) ||
        student.student_id.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Sort alphabetically by last name, then first name, then middle initial
    filteredData.sort((a, b) => {
      const nameA = `${a.last_name}, ${a.first_name} ${a.middle_initial || ''}`.toLowerCase();
      const nameB = `${b.last_name}, ${b.first_name} ${b.middle_initial || ''}`.toLowerCase();
      if (nameA < nameB) return -1;
      if (nameA > nameB) return 1;
      return 0;
    });

    setStudentData(filteredData);
  }, [selectedYear, selectedSection, searchQuery, allStudents]);

  return (
    <div className="student-information-container">
      <h2>Student Information</h2>
      <div className="desc">
        Keep all your student details—name, ID, section, year, and email—organized and accessible in one convenient place.
      </div>
      <div className="filters-box">
        <div className="filters-header">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="size-6">
            <path d="M18.75 12.75h1.5a.75.75 0 0 0 0-1.5h-1.5a.75.75 0 0 0 0 1.5ZM12 6a.75.75 0 0 1 .75-.75h7.5a.75.75 0 0 1 0 1.5h-7.5A.75.75 0 0 1 12 6ZM12 18a.75.75 0 0 1 .75-.75h7.5a.75.75 0 0 1 0 1.5h-7.5A.75.75 0 0 1 12 18ZM3.75 6.75h1.5a.75.75 0 1 0 0-1.5h-1.5a.75.75 0 0 0 0 1.5ZM5.25 18.75h-1.5a.75.75 0 0 1 0-1.5h1.5a.75.75 0 0 1 0 1.5ZM3 12a.75.75 0 0 1 .75-.75h7.5a.75.75 0 0 1 0 1.5h-7.5A.75.75 0 0 1 3 12ZM9 3.75a2.25 2.25 0 1 0 0 4.5 2.25 2.25 0 0 0 0-4.5ZM12.75 12a2.25 2.25 0 1 1 4.5 0 2.25 2.25 0 0 1-4.5 0ZM9 15.75a2.25 2.25 0 1 0 0 4.5 2.25 2.25 0 0 0 0-4.5Z" />
          </svg>
          Filters:
        </div>
        <form className="filter-form">
          <div className="filter-group">
            <label htmlFor="year-select">Year</label>
            <div className="custom-select-wrapper">
              <select id="year-select" className="custom-select" onChange={(e) => setSelectedYear(e.target.value)} value={selectedYear}>
                <option>All</option>
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
              </select>
            </div>
          </div>
          <div className="filter-group">
            <label htmlFor="section-select">Section</label>
            <div className="custom-select-wrapper">
              <select id="section-select" className="custom-select" onChange={(e) => setSelectedSection(e.target.value)} value={selectedSection}>
                <option>All</option>
                <option>A</option>
                <option>B</option>
              </select>
            </div>
          </div>
          <div className="filter-group">
            <label htmlFor="search-input">Search</label>
            <input type="text" id="search-input" placeholder="Search..." onChange={(e) => setSearchQuery(e.target.value)} value={searchQuery} />
          </div>
        </form>
      </div>
      <div className="actions">
        <button className="add-student-btn" onClick={() => setIsModalOpen(true)}>Add student</button>
        
        
      </div>
      <table>
        <thead>
          <tr>
            <th>STUDENT ID</th>
            <th>NAME</th>
            <th>YR&SEC</th>
            <th>REMAINING MTL SESSION TIME</th>
          </tr>
        </thead>
        <tbody>
          {paginate(studentData).map((student) => (
            <tr key={student.student_id} className={student.rowClass}>
              <td>{student.student_id}</td>
              <td>{`${student.last_name}, ${student.first_name}${student.middle_initial ? ` ${student.middle_initial}.` : ''}`}</td>
              <td>{`${student.year}${student.sec}`}</td>
              <td>{`${Math.floor(student.mtl_time_remaining / 60)}hr ${student.mtl_time_remaining % 60}mins`}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="pagination">
        <button onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}>&lt;</button>
        <span>{currentPage} of {Math.ceil(studentData.length / itemsPerPage)}</span>
        <button onClick={() => setCurrentPage(prev => Math.min(Math.ceil(studentData.length / itemsPerPage), prev + 1))}>&gt;</button>
      </div>
      {isModalOpen && <AddStudentModal onClose={() => {
        setIsModalOpen(false);
        fetchStudents();
      }} />}
    </div>
  );
};

export default StudentInformation;