import React, { useState } from 'react';
import './ui_css/AddUserForm.css';

interface AddUserFormProps {
  onUserAdded: (message: string, type: 'success' | 'error') => void;
}

const AddUserForm: React.FC<AddUserFormProps> = ({ onUserAdded }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('Student Assistant'); // Default role
  const [phone, setPhone] = useState('');

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    try {
      const response = await fetch('/api/admin/add-user', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, email, password, role, phone: phone || null }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Failed to add user');
      }

      onUserAdded(data.message || 'User added successfully!', 'success');
      // Clear form fields
      setName('');
      setEmail('');
      setPassword('');
      setRole('Student Assistant');
      setPhone('');
    } catch (error: any) {
      console.error('Error adding user:', error);
      onUserAdded(error.message || 'Failed to add user.', 'error');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="add-user-form">
        <div className="form-group">
          <label htmlFor="name">Name</label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="phone">Phone (Optional)</label>
          <input
            type="text"
            id="phone"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
          />
        </div>
        <div className="form-group">
          <label htmlFor="role">Role</label>
          <select
            id="role"
            value={role}
            onChange={(e) => setRole(e.target.value)}
            required
          >
            <option value="Administrator">Administrator</option>
            <option value="Music Dean">Music Dean</option>
            <option value="Student Assistant">Student Assistant</option>
          </select>
        </div>
        <button type="submit" className="add-user-button">Add User</button>
    </form>
  );
};

export default AddUserForm;
