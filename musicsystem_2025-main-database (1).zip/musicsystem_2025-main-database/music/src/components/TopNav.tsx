import React from 'react';
import './ui_css/TopNav.css';
import { useAuth } from './login/AuthProvider';

interface TopNavProps {
  isCollapsed: boolean;
  toggleSidebar: () => void;
  isModalOpen: boolean; // New prop
}

const TopNav: React.FC<TopNavProps> = ({ isCollapsed, toggleSidebar, isModalOpen }) => {
  const { user } = useAuth();

  return (
    <div className={`top-nav-container ${isCollapsed ? 'collapsed' : ''} ${isModalOpen ? 'modal-active' : ''}`}>
      <button className="chevron-btn" onClick={toggleSidebar}>
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <line x1="3" y1="12" x2="21" y2="12"></line>
          <line x1="3" y1="6" x2="21" y2="6"></line>
          <line x1="3" y1="18" x2="21" y2="18"></line>
        </svg>  
      </button>
      <div className="user-profile">
        <div className="user-avatar">
          <img src={user?.profile_picture_path ? `/uploads/profile_pictures/${user.profile_picture_path}` : '/default.jpeg'} alt="Profile" />
        </div>
        <div className="user-info">
          <span className="user-name">{user?.name || 'Guest'}</span>
          <span className="user-role">{user?.role || '-'}</span>
        </div>
      </div>
    </div>
  );
};

export default TopNav;