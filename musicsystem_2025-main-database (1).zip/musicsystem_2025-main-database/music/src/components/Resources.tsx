import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import ConfirmationModal from './modals/ConfirmationModal';
import SuccessTimeoutModal from './modals/SuccessTimeoutModal';
import InstrumentTimeout from './modals/InstrumentTimeout';
import FailureModal from './modals/FailureModal';
import './ui_css/Resources.css';

interface CubicleData {
  cubicle_id: number;
  cubicle_no: number;
  cubicle_type: string;
  status: string;
  name: string;
  yr_sec: string;
  time_in: string;
}

interface InstrumentData {
  instrument_id: number;
  instrument_no: number;
  instrument_type: string;
  status: string;
  name: string;
  yr_sec: string;
  time_in: string;
}

const Resources = () => {
  const location = useLocation();
  const { filter, status } = location.state || {};

  const [pianoCubicles, setPianoCubicles] = useState<CubicleData[]>([]);
  const [guitarCubicles, setGuitarCubicles] = useState<CubicleData[]>([]);
  const [mtlCubicles, setMtlCubicles] = useState<CubicleData[]>([]);
  const [instrumentData, setInstrumentData] = useState<InstrumentData[]>([]);
  

  const [pianoPage, setPianoPage] = useState(1);
  const [guitarPage, setGuitarPage] = useState(1);
  const [mtlPage, setMtlPage] = useState(1);
  const [instrumentPage, setInstrumentPage] = useState(1);

  const itemsPerPage = 1;

  const [showConfirmationModal, setShowConfirmationModal] = useState(false);
  const [itemToTimeout, setItemToTimeout] = useState<{ id: number; type: string } | null>(null);
  const [showResultModal, setShowResultModal] = useState(false);
  const [timeoutResult, setTimeoutResult] = useState<any>(null);
  const [showSuccessTimeoutModal, setShowSuccessTimeoutModal] = useState(false);
  const [showInstrumentTimeoutModal, setShowInstrumentTimeoutModal] = useState(false);
  const [timeoutDetails, setTimeoutDetails] = useState<any>(null);

  
  const [selectedTable, setSelectedTable] = useState(filter === 'instruments' ? 'instruments' : 'cubicles'); // New state for toggling tables

  const [pianoInstruments, setPianoInstruments] = useState<InstrumentData[]>([]);
  const [guitarInstruments, setGuitarInstruments] = useState<InstrumentData[]>([]);
  const [violinInstruments, setViolinInstruments] = useState<InstrumentData[]>([]);

  const [pianoInstrumentPage, setPianoInstrumentPage] = useState(1);
  const [guitarInstrumentPage, setGuitarInstrumentPage] = useState(1);
  const [violinInstrumentPage, setViolinInstrumentPage] = useState(1);

  const fetchCubicleData = async () => {
    try {
      const response = await fetch('http://localhost:3001/api/cubicles');
      const data = await response.json();

      if (Array.isArray(data)) {
        const piano = data.filter((c: CubicleData) => c.cubicle_type === 'Piano');
        const guitar = data.filter((c: CubicleData) => c.cubicle_type === 'Guitar');
        const mtl = data.filter((c: CubicleData) => c.cubicle_type === 'MTL');

        setPianoCubicles(piano);
        setGuitarCubicles(guitar);
        setMtlCubicles(mtl);
      } else {
        setPianoCubicles([]);
        setGuitarCubicles([]);
        setMtlCubicles([]);
        console.error('Fetched cubicle data is not an array:', data);
      }
    } catch (error) {
      console.error('Error fetching cubicle data:', error);
      setPianoCubicles([]);
      setGuitarCubicles([]);
      setMtlCubicles([]);
    }
  };

  const fetchInstrumentData = async () => {
    try {
      const response = await fetch('http://localhost:3001/api/instruments');
      let data = await response.json();
      if (Array.isArray(data)) {
        if (filter === 'instruments') { // Only filter by instrument type, not status
          // No status filtering here, show all instruments
        }
        setInstrumentData(data);

        const piano = data.filter((i: InstrumentData) => i.instrument_type === 'Piano');
        const guitar = data.filter((i: InstrumentData) => i.instrument_type === 'Guitar');
        const violin = data.filter((i: InstrumentData) => i.instrument_type === 'Violin');

        setPianoInstruments(piano);
        setGuitarInstruments(guitar);
        setViolinInstruments(violin);
      } else {
        setInstrumentData([]);

        console.error('Fetched instrument data is not an array:', data);
      }
    } catch (error) {
      console.error('Error fetching instrument data:', error);
      setInstrumentData([]);
    }
  };

  useEffect(() => {
    fetchCubicleData();
    fetchInstrumentData();
  }, [filter, status]);

  

  const paginate = (data: any[], page: number) => {
    const startIndex = (page - 1) * itemsPerPage;
    return data.slice(startIndex, startIndex + itemsPerPage);
  };

  const handleTimeOut = async (id: number, type: string) => {
    setItemToTimeout({ id, type });
    setShowConfirmationModal(true);
  };

  const confirmTimeOut = async () => {
    if (!itemToTimeout) return;

    const { id, type } = itemToTimeout;
    console.log('itemToTimeout.type:', type);
    setShowConfirmationModal(false);

    const isInstrument = type === 'instrument';
    const endpoint = isInstrument ? 'http://localhost:3001/api/timeout-instrument' : 'http://localhost:3001/api/timeout-cubicle';
    const body = isInstrument ? { instrument_id: id } : { cubicle_id: id };

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(body),
      });

      const data = await response.json();

      if (response.ok) {
        if (isInstrument) {
            const instrument = instrumentData.find(i => i.instrument_id === id);
            if (instrument) {
                const timeIn = new Date(instrument.time_in);
                const timeOut = new Date();
                const durationInMinutes = Math.round((timeOut.getTime() - timeIn.getTime()) / 60000);
                const durationHours = Math.floor(durationInMinutes / 60);
                const durationMinutes = durationInMinutes % 60;
                const formattedDuration = `${durationHours}hr ${durationMinutes}min`;

                setTimeoutDetails({
                    name: instrument.name,
                    instrumentType: `${instrument.instrument_type} Instrument #${instrument.instrument_no}`,
                    releaseTime: timeIn.toLocaleTimeString(),
                    returnTime: timeOut.toLocaleTimeString(),
                    duration: formattedDuration,
                });
                setShowInstrumentTimeoutModal(true);
            }
            fetchInstrumentData();
        } else {
            const allCubicles = [...pianoCubicles, ...guitarCubicles, ...mtlCubicles];
            const cubicleData = allCubicles.find(c => c.cubicle_id === id);

            if (cubicleData) {
              const timeIn = new Date(cubicleData.time_in);
              const timeOut = new Date();
              const durationInMinutes = Math.round((timeOut.getTime() - timeIn.getTime()) / 60000);
              const hours = Math.floor(durationInMinutes / 60);
              const minutes = durationInMinutes % 60;
              const duration = `${hours}hr ${minutes}min`;

              setTimeoutDetails({
                name: cubicleData.name,
                room: `${cubicleData.cubicle_type} Cubicle #${cubicleData.cubicle_no}`,
                timeIn: timeIn.toLocaleTimeString(),
                timeOut: timeOut.toLocaleTimeString(),
                duration: duration,
              });
              setShowSuccessTimeoutModal(true);
            }
            fetchCubicleData();
        }
      } else {
        setTimeoutResult({
          message: data.message || 'Unknown error',
          id: id,
        });
        setShowResultModal(true);
      }
    } catch (error) {
      console.error('Error during timeout API call:', error);
      setTimeoutResult({
        message: 'An error occurred while trying to time out.',
        id: id,
      });
      setShowResultModal(true);
    } finally {
      setItemToTimeout(null);
    }
  };

  const cancelTimeOut = () => {
    setShowConfirmationModal(false);
    setItemToTimeout(null);
  };

  const handleCloseResultModal = () => {
    setShowResultModal(false);
    setTimeoutResult(null);
    setShowSuccessTimeoutModal(false);
    setShowInstrumentTimeoutModal(false); // Reset instrument timeout modal state
    setTimeoutDetails(null);
  };

  return (
    <div className="resources-container">
        <h1>Resources overview</h1>
        <p className="description">
          View all music room cubicles and instruments with their real-time status at a glance. Easily check availability to plan your practice or booking efficiently.
        </p>

        <section className="filters-box" aria-label="Filters">
          <div className="filters-header">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="size-6">
              <path d="M18.75 12.75h1.5a.75.75 0 0 0 0-1.5h-1.5a.75.75 0 0 0 0 1.5ZM12 6a.75.75 0 0 1 .75-.75h7.5a.75.75 0 0 1 0 1.5h-7.5A.75.75 0 0 1 12 6ZM12 18a.75.75 0 0 1 .75-.75h7.5a.75.75 0 0 1 0 1.5h-7.5A.75.75 0 0 1 12 18ZM3.75 6.75h1.5a.75.75 0 1 0 0-1.5h-1.5a.75.75 0 0 0 0 1.5ZM5.25 18.75h-1.5a.75.75 0 0 1 0-1.5h1.5a.75.75 0 0 1 0 1.5ZM3 12a.75.75 0 0 1 .75-.75h7.5a.75.75 0 0 1 0 1.5h-7.5A.75.75 0 0 1 3 12ZM9 3.75a2.25 2.25 0 1 0 0 4.5 2.25 2.25 0 0 0 0-4.5ZM12.75 12a2.25 2.25 0 1 1 4.5 0 2.25 2.25 0 0 1-4.5 0ZM9 15.75a2.25 2.25 0 1 0 0 4.5 2.25 2.25 0 0 0 0-4.5Z" />
            </svg>
            Filters:
          </div>
          <div className="filter-buttons" role="group" aria-label="Filter by Cubicle or Instrument">
            <button type="button" onClick={() => setSelectedTable('cubicles')} className={selectedTable === 'cubicles' ? 'active' : ''}>Cubicles</button>
            <button type="button" onClick={() => setSelectedTable('instruments')} className={selectedTable === 'instruments' ? 'active' : ''}>Instrument</button>
          </div>
          
        </section>

        

        <section className='table-section-container'>

        {selectedTable === 'cubicles' && (
          <div className="cubicle-sections-container">

            
            {/* Piano Cubicles */}
            <section className="table-section" aria-label="Piano Cubicles Table">
              <div className="section-header">
                <span className="icon-pink">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" d="M15.5 12c-.5-.3-1.2-.9-1.6-1.7c-.5-.7-.9-1.7-1.2-2.5c-.5-1.5-1.1-2.7-1.9-3.6S8.9 2.9 7.3 3c-2 .1-3.1 1-3.7 2S3 7 3 7v13c0 .3.1.5.3.7c0 .2.3.3.6.3h15.9c.3 0 .5-.1.7-.3s.4-.4.4-.7c.2-1.1.4-2.9 0-4.5s-1.2-2.9-3.1-3c-.5 0-.9-.1-1.3-.2c-.3-.1-.7-.2-1-.3m-6.2 4.3v2.8h1v-2.8h.8v2.8h1v-2.8h.8v2.8H14v-2.8h1.6v2.8h1v-2.8h.8v2.8h1v-2.8h1.4V20h-16v-3.6h1v2.8h1v-2.8h.8v2.8h1v-2.8"/></svg>
                </span>
                <span className="section-title">Piano Cubicles</span>
              </div>

        <div className='table-div'>
              <table>
                <thead>
                  <tr>
                    <th>Cubicle No.</th>
                    <th>Status</th>
                    <th>Name</th>
                    <th>Yr & Sec</th>
                    <th>Time in</th>
                    <th>Time out</th>
                  </tr>
                </thead>
                <tbody>
                  {paginate(pianoCubicles, pianoPage).map((row) => (
                    <tr key={row.cubicle_id}>
                      <td>{row.cubicle_no}</td>
                      <td>{row.status}</td>
                      <td>{row.name}</td>
                      <td>{row.yr_sec}</td>
                      <td>
                        {row.time_in !== '-' ? (
                          <>
                            <div>{new Date(row.time_in).toLocaleTimeString()}</div>
                            <div>{new Date(row.time_in).toLocaleDateString()}</div>
                          </>
                        ) : (
                          '-'
                        )}
                      </td>
                      <td>
                        <button
                          onClick={() => handleTimeOut(row.cubicle_id, 'cubicle')}
                          disabled={row.status !== 'Occupied'}
                          className="timeout-button"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="size-5">
                            <path fillRule="evenodd" d="M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm.75-13a.75.75 0 0 0-1.5 0v5c0 .414.336.75.75.75h4a.75.75 0 0 0 0-1.5h-3.25V5Z" clipRule="evenodd" />
                          </svg>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="pagination">
                <button onClick={() => setPianoPage(prev => Math.max(1, prev - 1))}>&lt;</button>
                <span>{pianoPage} of {Math.ceil(pianoCubicles.length / itemsPerPage)}</span>
                <button onClick={() => setPianoPage(prev => Math.min(Math.ceil(pianoCubicles.length / itemsPerPage), prev + 1))}>&gt;</button>
              </div>
              </div>
            </section>


            {/* Guitar Cubicles */}
            <section className="table-section" aria-label="Guitar Cubicles Table">
              <div className="section-header">
                <span className="icon-pink">
                  <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><circle cx="17.067" cy="56.547" r="1.844" fill="currentColor"/><path fill="currentColor" d="m24.759 44.225l-4.987-4.982l2.443-2.445L27.2 41.78zm-9.771-.199l2.444-2.443l4.983 4.984l-2.444 2.444zm-1.565 2.787l3.86 3.86l-1.393 1.393l-3.86-3.86zm7.512 5.213a2.306 2.306 0 1 0 3.262 0c-.901-.9-2.361-.9-3.262 0"/><path fill="currentColor" d="m59.897 12.03l-.496-.495c3.267-3.104 3.558-3.941.281-7.216c-3.277-3.28-4.115-2.986-7.218.28l-.494-.495c.433-.53.614-1.058.135-1.537c-.59-.589-1.25-.19-1.903.463c-.652.652-1.049 1.311-.461 1.898c.48.479 1.006.301 1.537-.132l.516.516c-.753.803-1.628 1.742-2.678 2.821l-.588-.588c.434-.531.611-1.057.134-1.537c-.589-.586-1.249-.191-1.899.459c-.654.654-1.051 1.313-.461 1.902c.479.479 1.006.298 1.537-.136l.595.595c-.115.116-.218.223-.337.342c-.916.916-1.708 1.713-2.391 2.433l-.617-.618c.432-.531.611-1.057.131-1.535c-.588-.588-1.248-.193-1.898.459c-.652.654-1.051 1.313-.461 1.9c.48.48 1.006.302 1.537-.132l.643.645c-1.969 2.182-2.646 3.573-1.898 5.143L30.276 29.606c-1.586-1.542-3.384-2.817-6.171-2.604c-6.663.504-2.295 8.092-10.83 8.66c-3.052.201-5.95.871-8.046 2.972c-5.33 5.328-3.626 12.642 1.934 18.204c5.559 5.56 12.874 7.261 18.203 1.934c2.779-2.777 2.686-7.816 3.615-10.827c1.199-3.891 7.463-2.574 7.176-6.902c-.025-.408-.125-.666-.281-.82c-.779-.779-2.963 1.078-4.276-.236c-.412-.41-.736-1.135-.906-2.34L46.535 20.86c1.57.749 2.963.07 5.146-1.899l.643.643c-.434.532-.611 1.059-.135 1.539c.588.588 1.25.191 1.902-.463c.652-.65 1.049-1.311.459-1.9c-.479-.478-1.005-.298-1.536.135l-.617-.616c.721-.683 1.517-1.475 2.433-2.392c.119-.119.227-.221.344-.337l.591.594c-.433.532-.612 1.058-.131 1.538c.588.588 1.247.191 1.899-.461c.648-.652 1.047-1.313.459-1.9c-.478-.479-1.004-.3-1.535.132l-.587-.587c1.078-1.051 2.017-1.926 2.819-2.677l.517.515c-.435.531-.612 1.058-.132 1.537c.588.586 1.247.191 1.898-.462c.654-.652 1.05-1.313.462-1.9c-.48-.481-1.006-.301-1.537.131m-27.67 30.605q-.134.057-.281.117c-1.775.73-4.211 1.729-5.078 4.541c-.318 1.027-.516 2.166-.725 3.375c-.412 2.382-.881 5.081-2.339 6.54c-2.039 2.039-4.439 2.875-7.139 2.49c-2.643-.375-5.464-1.945-7.941-4.424c-2.478-2.477-4.048-5.296-4.422-7.938c-.386-2.699.453-5.1 2.489-7.139c1.398-1.398 3.443-2.117 6.631-2.329c5.936-.393 7.287-3.85 8.181-6.137c.698-1.789.934-2.393 2.671-2.525c1.807-.137 3.018.598 4.394 1.918l-4.325 4.082l4.452 4.454l.08-.085c.272.814.653 1.467 1.162 1.976a3.7 3.7 0 0 0 2.19 1.084m15.546-28.209a1.283 1.283 0 1 1-1.813-1.816a1.283 1.283 0 0 1 1.813 1.816m1.643-5.273c.502-.5 1.314-.5 1.817 0a1.286 1.286 0 0 1-.002 1.814c-.503.502-1.315.5-1.813 0a1.28 1.28 0 0 1-.002-1.814m1.987 8.9a1.286 1.286 0 0 1-1.817-1.816c.504-.5 1.315-.5 1.817.002a1.28 1.28 0 0 1 0 1.814m1.469-12.355a1.28 1.28 0 0 1 1.814.002a1.283 1.283 0 1 1-1.814-.002m1.986 8.898a1.284 1.284 0 0 1-1.815-1.815c.5-.498 1.313-.5 1.816 0a1.285 1.285 0 0 1-.001 1.815m3.455-3.456A1.28 1.28 0 1 1 56.5 9.328c.5-.504 1.313-.502 1.814 0s.503 1.31-.001 1.812"/></svg>
                </span>
                <span className="section-title">Guitar Cubicles</span>
              </div>

            <div className='table-div'>
              <table>
                <thead>
                  <tr>
                    <th>Cubicle No.</th>
                    <th>Status</th>
                    <th>Name</th>
                    <th>Yr & Sec</th>
                    <th>Time in</th>
                    <th>Time out</th>
                  </tr>
                </thead>
                <tbody>
                  {paginate(guitarCubicles, guitarPage).map((row) => (
                    <tr key={row.cubicle_id}>
                      <td>{row.cubicle_no}</td>
                      <td>{row.status}</td>
                      <td>{row.name}</td>
                      <td>{row.yr_sec}</td>
                      <td>
                        {row.time_in !== '-' ? (
                          <>
                            <div>{new Date(row.time_in).toLocaleTimeString()}</div>
                            <div>{new Date(row.time_in).toLocaleDateString()}</div>
                          </>
                        ) : (
                          '-'
                        )}
                      </td>
                      <td>
                        <button
                          onClick={() => handleTimeOut(row.cubicle_id, 'cubicle')}
                          disabled={row.status !== 'Occupied'}
                          className="timeout-button"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="size-5">
                            <path fillRule="evenodd" d="M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm.75-13a.75.75 0 0 0-1.5 0v5c0 .414.336.75.75.75h4a.75.75 0 0 0 0-1.5h-3.25V5Z" clipRule="evenodd" />
                          </svg>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="pagination">
                <button onClick={() => setGuitarPage(prev => Math.max(1, prev - 1))}>&lt;</button>
                <span>{guitarPage} of {Math.ceil(guitarCubicles.length / itemsPerPage)}</span>
                <button onClick={() => setGuitarPage(prev => Math.min(Math.ceil(guitarCubicles.length / itemsPerPage), prev + 1))}>&gt;</button>
              </div>
            </div>
            </section>

            {/* MTL Cubicle */}
            <section className="table-section" aria-label="MTL Cubicles Table">
              <div className="section-header">
                <span className="icon-pink">
                  <svg xmlns="http://www.w3.org/2000/svg" width="56" height="56" viewBox="0 0 56 56"><path fill="currentColor" d="M.625 27.824c0 1.125.89 1.805 1.992 1.805c.68 0 1.219-.328 1.688-.797L27.18 7.996c.257-.258.539-.352.843-.352c.282 0 .54.094.82.352l22.852 20.836c.492.469 1.031.797 1.688.797c1.101 0 1.992-.68 1.992-1.805c0-.703-.258-1.148-.703-1.547l-8.11-7.382V5.043c0-1.031-.656-1.687-1.687-1.687h-3.07c-1.008 0-1.711.656-1.711 1.687v7.969l-9.282-8.485C29.992 3.754 28.984 3.38 28 3.38c-.985 0-1.969.375-2.813 1.148L1.328 26.277c-.422.399-.703.844-.703 1.547m6.703 19.664c0 3.258 1.969 5.157 5.273 5.157h30.82c3.305 0 5.25-1.899 5.25-5.157V30.332l-19.898-17.93c-.258-.234-.539-.351-.82-.351c-.258 0-.516.117-.797.375L7.328 30.449Zm25.781-16.382l-5.344 1.288c-.492.118-.703.329-.703 1.172v7.852c0 3.281-2.18 5.625-5.437 5.625c-2.273 0-3.75-1.406-3.75-3.352c0-2.226 1.734-3.445 3.82-3.984l2.086-.562c1.149-.282 1.242-.493 1.242-1.524V27.355c0-1.335.258-1.57 1.383-1.851l6.633-1.64c1.195-.305 1.5.07 1.5.96v4.453c0 1.313-.328 1.57-1.43 1.828"/></svg>
                </span>
                <span className="section-title">MTL Cubicles</span>
              </div>

          <div className='table-div'>
              <table>
                <thead>
                  <tr>
                    <th>Cubicle No.</th>
                    <th>Status</th>
                    <th>Name</th>
                    <th>Yr & Sec</th>
                    <th>Time in</th>
                    <th>Time out</th>
                  </tr>
                </thead>
                <tbody>
                  {paginate(mtlCubicles, mtlPage).map((row) => (
                    <tr key={row.cubicle_id}>
                      <td>{row.cubicle_no}</td>
                      <td>{row.status}</td>
                      <td>{row.name}</td>
                      <td>{row.yr_sec}</td>
                      <td>
                        {row.time_in !== '-' ? (
                          <>
                            <div>{new Date(row.time_in).toLocaleTimeString()}</div>
                            <div>{new Date(row.time_in).toLocaleDateString()}</div>
                          </>
                        ) : (
                          '-'
                        )}
                      </td>
                      <td>
                        <button
                          onClick={() => handleTimeOut(row.cubicle_id, 'cubicle')}
                          disabled={row.status !== 'Occupied'}
                          className="timeout-button"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="size-5">
                            <path fillRule="evenodd" d="M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm.75-13a.75.75 0 0 0-1.5 0v5c0 .414.336.75.75.75h4a.75.75 0 0 0 0-1.5h-3.25V5Z" clipRule="evenodd" />
                          </svg>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="pagination">
                <button onClick={() => setMtlPage(prev => Math.max(1, prev - 1))}>&lt;</button>
                <span>{mtlPage} of {Math.ceil(mtlCubicles.length / itemsPerPage)}</span>
                <button onClick={() => setMtlPage(prev => Math.min(Math.ceil(mtlCubicles.length / itemsPerPage), prev + 1))}>&gt;</button>
              </div>
            </div>
            </section>

        </div>
        )}

       

        {selectedTable === 'instruments' && (
          <div className="cubicle-sections-container">

            
            {/* Piano Instruments */}
            <section className="table-section" aria-label="Piano Instruments Table">
              <div className="section-header">
                <span className="icon-pink">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" d="M15.5 12c-.5-.3-1.2-.9-1.6-1.7c-.5-.7-.9-1.7-1.2-2.5c-.5-1.5-1.1-2.7-1.9-3.6S8.9 2.9 7.3 3c-2 .1-3.1 1-3.7 2S3 7 3 7v13c0 .3.1.5.3.7c0 .2.3.3.6.3h15.9c.3 0 .5-.1.7-.3s.4-.4.4-.7c.2-1.1.4-2.9 0-4.5s-1.2-2.9-3.1-3c-.5 0-.9-.1-1.3-.2c-.3-.1-.7-.2-1-.3m-6.2 4.3v2.8h1v-2.8h.8v2.8h1v-2.8h.8v2.8H14v-2.8h1.6v2.8h1v-2.8h.8v2.8h1v-2.8h1.4V20h-16v-3.6h1v2.8h1v-2.8h.8v2.8h1v-2.8"/></svg>
                </span>
                <span className="section-title">Piano</span>
              </div>

        <div className='table-div'>
              <table>
                <thead>
                  <tr>
                    <th>Instrument No.</th>
                    <th>Status</th>
                    <th>Name</th>
                    <th>Yr & Sec</th>
                    <th>Release Time</th>
                    <th>Return</th>
                  </tr>
                </thead>
                <tbody>
                  {paginate(pianoInstruments, pianoInstrumentPage).map((row) => (
                    <tr key={row.instrument_id}>
                      <td>{row.instrument_no}</td>
                      <td>{row.status}</td>
                      <td>{row.name}</td>
                      <td>{row.yr_sec}</td>
                      <td>
                        {row.time_in !== '-' ? (
                          <>
                            <div>{new Date(row.time_in).toLocaleTimeString()}</div>
                            <div>{new Date(row.time_in).toLocaleDateString()}</div>
                          </>
                        ) : (
                          '-'
                        )}
                      </td>
                      <td>
                        <button
                          onClick={() => handleTimeOut(row.instrument_id, 'instrument')}
                          disabled={row.status !== 'Borrowed'}
                          className="timeout-button"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="size-5">
                            <path fillRule="evenodd" d="M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm.75-13a.75.75 0 0 0-1.5 0v5c0 .414.336.75.75.75h4a.75.75 0 0 0 0-1.5h-3.25V5Z" clipRule="evenodd" />
                          </svg>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="pagination">
                <button onClick={() => setPianoInstrumentPage(prev => Math.max(1, prev - 1))}>&lt;</button>
                <span>{pianoInstrumentPage} of {Math.ceil(pianoInstruments.length / itemsPerPage)}</span>
                <button onClick={() => setPianoInstrumentPage(prev => Math.min(Math.ceil(pianoInstruments.length / itemsPerPage), prev + 1))}>&gt;</button>
              </div>
              </div>
            </section>


            {/* Guitar Instruments */}
            <section className="table-section" aria-label="Guitar Instruments Table">
              <div className="section-header">
                <span className="icon-pink">
                  <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><circle cx="17.067" cy="56.547" r="1.844" fill="currentColor"/><path fill="currentColor" d="m24.759 44.225l-4.987-4.982l2.443-2.445L27.2 41.78zm-9.771-.199l2.444-2.443l4.983 4.984l-2.444 2.444zm-1.565 2.787l3.86 3.86l-1.393 1.393l-3.86-3.86zm7.512 5.213a2.306 2.306 0 1 0 3.262 0c-.901-.9-2.361-.9-3.262 0"/><path fill="currentColor" d="m59.897 12.03l-.496-.495c3.267-3.104 3.558-3.941.281-7.216c-3.277-3.28-4.115-2.986-7.218.28l-.494-.495c.433-.53.614-1.058.135-1.537c-.59-.589-1.25-.19-1.903.463c-.652.652-1.049 1.311-.461 1.898c.48.479 1.006.301 1.537-.132l.516.516c-.753.803-1.628 1.742-2.678 2.821l-.588-.588c.434-.531.611-1.057.134-1.537c-.589-.586-1.249-.191-1.899.459c-.654.654-1.051 1.313-.461 1.902c.479.479 1.006.298 1.537-.136l.595.595c-.115.116-.218.223-.337.342c-.916.916-1.708 1.713-2.391 2.433l-.617-.618c.432-.531.611-1.057.131-1.535c-.588-.588-1.248-.193-1.898.459c-.652.654-1.051 1.313-.461 1.9c.48.48 1.006.302 1.537-.132l.643.645c-1.969 2.182-2.646 3.573-1.898 5.143L30.276 29.606c-1.586-1.542-3.384-2.817-6.171-2.604c-6.663.504-2.295 8.092-10.83 8.66c-3.052.201-5.95.871-8.046 2.972c-5.33 5.328-3.626 12.642 1.934 18.204c5.559 5.56 12.874 7.261 18.203 1.934c2.779-2.777 2.686-7.816 3.615-10.827c1.199-3.891 7.463-2.574 7.176-6.902c-.025-.408-.125-.666-.281-.82c-.779-.779-2.963 1.078-4.276-.236c-.412-.41-.736-1.135-.906-2.34L46.535 20.86c1.57.749 2.963.07 5.146-1.899l.643.643c-.434.532-.611 1.059-.135 1.539c.588.588 1.25.191 1.902-.463c.652-.65 1.049-1.311.459-1.9c-.479-.478-1.005-.298-1.536.135l-.617-.616c.721-.683 1.517-1.475 2.433-2.392c.119-.119.227-.221.344-.337l.591.594c-.433.532-.612 1.058-.131 1.538c.588.588 1.247.191 1.899-.461c.648-.652 1.047-1.313.459-1.9c-.478-.479-1.004-.3-1.535.132l-.587-.587c1.078-1.051 2.017-1.926 2.819-2.677l.517.515c-.435.531-.612 1.058-.132 1.537c.588.586 1.247.191 1.898-.462c.654-.652 1.05-1.313.462-1.9c-.48-.481-1.006-.301-1.537.131m-27.67 30.605q-.134.057-.281.117c-1.775.73-4.211 1.729-5.078 4.541c-.318 1.027-.516 2.166-.725 3.375c-.412 2.382-.881 5.081-2.339 6.54c-2.039 2.039-4.439 2.875-7.139 2.49c-2.643-.375-5.464-1.945-7.941-4.424c-2.478-2.477-4.048-5.296-4.422-7.938c-.386-2.699.453-5.1 2.489-7.139c1.398-1.398 3.443-2.117 6.631-2.329c5.936-.393 7.287-3.85 8.181-6.137c.698-1.789.934-2.393 2.671-2.525c1.807-.137 3.018.598 4.394 1.918l-4.325 4.082l4.452 4.454l.08-.085c.272.814.653 1.467 1.162 1.976a3.7 3.7 0 0 0 2.19 1.084m15.546-28.209a1.283 1.283 0 1 1-1.813-1.816a1.283 1.283 0 0 1 1.813 1.816m1.643-5.273c.502-.5 1.314-.5 1.817 0a1.286 1.286 0 0 1-.002 1.814c-.503.502-1.315.5-1.813 0a1.28 1.28 0 0 1-.002-1.814m1.987 8.9a1.286 1.286 0 0 1-1.817-1.816c.504-.5 1.315-.5 1.817.002a1.28 1.28 0 0 1 0 1.814m1.469-12.355a1.28 1.28 0 0 1 1.814.002a1.283 1.283 0 1 1-1.814-.002m1.986 8.898a1.284 1.284 0 0 1-1.815-1.815c.5-.498 1.313-.5 1.816 0a1.285 1.285 0 0 1-.001 1.815m3.455-3.456A1.28 1.28 0 1 1 56.5 9.328c.5-.504 1.313-.502 1.814 0s.503 1.31-.001 1.812"/></svg>
                </span>
                <span className="section-title">Guitar</span>
              </div>

            <div className='table-div'>
              <table>
                <thead>
                  <tr>
                    <th>Instrument No.</th>
                    <th>Status</th>
                    <th>Name</th>
                    <th>Yr & Sec</th>
                    <th>Release Time</th>
                    <th>Return</th>
                  </tr>
                </thead>
                <tbody>
                  {paginate(guitarInstruments, guitarInstrumentPage).map((row) => (
                    <tr key={row.instrument_id}>
                      <td>{row.instrument_no}</td>
                      <td>{row.status}</td>
                      <td>{row.name}</td>
                      <td>{row.yr_sec}</td>
                      <td>
                        {row.time_in !== '-' ? (
                          <>
                            <div>{new Date(row.time_in).toLocaleTimeString()}</div>
                            <div>{new Date(row.time_in).toLocaleDateString()}</div>
                          </>
                        ) : (
                          '-'
                        )}
                      </td>
                      <td>
                        <button
                          onClick={() => handleTimeOut(row.instrument_id, 'instrument')}
                          disabled={row.status !== 'Borrowed'}
                          className="timeout-button"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="size-5">
                            <path fillRule="evenodd" d="M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm.75-13a.75.75 0 0 0-1.5 0v5c0 .414.336.75.75.75h4a.75.75 0 0 0 0-1.5h-3.25V5Z" clipRule="evenodd" />
                          </svg>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="pagination">
                <button onClick={() => setGuitarInstrumentPage(prev => Math.max(1, prev - 1))}>&lt;</button>
                <span>{guitarInstrumentPage} of {Math.ceil(guitarInstruments.length / itemsPerPage)}</span>
                <button onClick={() => setGuitarInstrumentPage(prev => Math.min(Math.ceil(guitarInstruments.length / itemsPerPage), prev + 1))}>&gt;</button>
              </div>
            </div>
            </section>

            {/* Violin Instruments */}
            <section className="table-section" aria-label="Violin Instruments Table">
              <div className="section-header">
                <span className="icon-pink">
                  <svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512"><path fill="currentColor" d="m470.9 26l-23 7.69l-.1 12.66l17.8 17.81l12.7-.1l7.7-23.04zm-32.5 37l-227 210.5l27.2 27L449 73.57zm-39.6-19.33L385.7 56.7l15.6 15.5l13.5-12.53zm53.5 53.59l-12.5 13.54l15.5 15.4l13.1-13zm-79.6-27.52l-13 13.02l14.6 14.61l13.5-12.58zm54.5 54.46l-12.5 13.6l14.5 14.5l13.1-13.1zm-124 39.2c-28.7-17.5-72-25.4-116.3 47.8l-7.2-1.4l-7.3 13c3.8 1 13.5 8.2 12.4 12.1c-3.5 11.3-48.2 64.3-70.6 44.5c-2.9-2.6-5.8-5.7-8-9.6l-14.35 7.9c1.23 10-1.95 13.8-6.38 15.8c-82.975 36.6-64.15 78.6-33.01 126.9l3.11-3c22.09-22.2 43.62-54.6 62.73-82.7l6.1-9.3l13 13l10.1-10.1l-10.8-10.9l18.8-7.3l5.1 5.2l33.3-33.4c-2.9-3-5.9-6-8.9-8.9zm45.5 45.5L239 327l-8.9-8.9l-33.3 33.3l5 5.1l-7.1 18.9l-10.9-11l-10.1 10.2l12.8 12.9l-9.2 6.3c-27.6 18.9-60.6 40.6-82.61 62.7l-3.14 3c48.45 31.2 90.45 50 127.05-33c2-4.4 5.7-7.6 15.8-6.4l7.8-14.3c-3.8-2.3-7-5-9.6-8c-19.8-22.4 33.2-67.2 44.5-70.7c3.9-1.1 11 8.6 12.1 12.4l13-7.1l-1.4-7.2c73.2-44.3 65.4-87.7 47.9-116.3M206.9 295l-33.2 33.3l10.1 10.1l33.3-33.3zm-46.3 46.3l-10.2 10.1l10.2 10.1l10.1-10.1zm-33.4 13c-16.4 24.2-34.63 51-54.84 72l2.97 10.3l10.36 3c21.11-20.1 48.01-38.4 72.11-54.8z"/></svg>
                </span>
                <span className="section-title">Violin</span>
              </div>

          <div className='table-div'>
              <table>
                <thead>
                  <tr>
                    <th>Instrument No.</th>
                    <th>Status</th>
                    <th>Name</th>
                    <th>Yr & Sec</th>
                    <th>Release Time</th>
                    <th>Return </th>
                  </tr>
                </thead>
                <tbody>
                  {paginate(violinInstruments, violinInstrumentPage).map((row) => (
                    <tr key={row.instrument_id}>
                      <td>{row.instrument_no}</td>
                      <td>{row.status}</td>
                      <td>{row.name}</td>
                      <td>{row.yr_sec}</td>
                      <td>
                        {row.time_in !== '-' ? (
                          <>
                            <div>{new Date(row.time_in).toLocaleTimeString()}</div>
                            <div>{new Date(row.time_in).toLocaleDateString()}</div>
                          </>
                        ) : (
                          '-'
                        )}
                      </td>
                      <td>
                        <button
                          onClick={() => handleTimeOut(row.instrument_id, 'instrument')}
                          disabled={row.status !== 'Borrowed'}
                          className="timeout-button"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="size-5">
                            <path fillRule="evenodd" d="M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm.75-13a.75.75 0 0 0-1.5 0v5c0 .414.336.75.75.75h4a.75.75 0 0 0 0-1.5h-3.25V5Z" clipRule="evenodd" />
                          </svg>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="pagination">
                <button onClick={() => setViolinInstrumentPage(prev => Math.max(1, prev - 1))}>&lt;</button>
                <span>{violinInstrumentPage} of {Math.ceil(violinInstruments.length / itemsPerPage)}</span>
                <button onClick={() => setViolinInstrumentPage(prev => Math.min(Math.ceil(violinInstruments.length / itemsPerPage), prev + 1))}>&gt;</button>
              </div>
            </div>
            </section>
          </div>
        )}

         </section>

      {showConfirmationModal && (
        <ConfirmationModal
          onClose={cancelTimeOut}
          onConfirm={confirmTimeOut}
          title="Are you sure?"
          message="This will time-out the student and end their current session. This action cannot be undone."
        />
      )}

      {showInstrumentTimeoutModal && timeoutDetails && (
        <InstrumentTimeout
          onClose={handleCloseResultModal}
          timeoutDetails={timeoutDetails}
        />
      )}

      {showSuccessTimeoutModal && timeoutDetails && !showInstrumentTimeoutModal && (
        <SuccessTimeoutModal
          onClose={handleCloseResultModal}
          timeoutDetails={timeoutDetails}
        />
      )}

      {showResultModal && timeoutResult && (
        <FailureModal
          onClose={handleCloseResultModal}
          errorMessage={timeoutResult.message}
          studentDetails={{
            studentId: 'N/A',
            name: 'N/A',
            availableTime: 'N/A',
          }}
        />
      )}
    </div>
  );
};

export default Resources;