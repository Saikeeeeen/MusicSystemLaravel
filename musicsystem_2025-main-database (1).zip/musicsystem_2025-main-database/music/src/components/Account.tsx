import React, { useState, useEffect, useRef } from 'react';
import './ui_css/Account.css';
import { useAuth } from './login/AuthProvider';
import ChangePasswordModal from './modals/ChangePasswordModal'; // Import the new modal
import SuccessMessageModal from './modals/SuccessMessageModal'; // Import the new success modal
import GenericFailureModal from './modals/GenericFailureModal'; // Import GenericFailureModal
import AddUserModal from './modals/AddUserModal'; // Import the new AddUserModal component

interface UserData {
  id: number;
  name: string;
  email: string;
  phone: string | null;
  role: string; // Added role
  profile_picture_path: string | null;
}

const Account = () => {
  const { user, updateUserProfile } = useAuth(); // Get authenticated user info and updateUserProfile
  const [userData, setUserData] = useState<UserData | null>(null);
  const [isChangePasswordModalOpen, setIsChangePasswordModalOpen] = useState(false); // State for change password modal
  const [isSuccessModalOpen, setIsSuccessModalOpen] = useState(false); // State for success modal
  const [successMessage, setSuccessMessage] = useState(''); // Message for success modal
  const [isFailureModalOpen, setIsFailureModalOpen] = useState(false); // State for failure modal
  const [failureMessage, setFailureMessage] = useState(''); // Message for failure modal
  const [isAddUserModalOpen, setIsAddUserModalOpen] = useState(false); // State to control AddUserModal visibility
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleAddUserMessage = (msg: string, type: 'success' | 'error') => {
    if (type === 'success') {
      setSuccessMessage(msg);
      setIsSuccessModalOpen(true);
    } else {
      setFailureMessage(msg);
      setIsFailureModalOpen(true);
    }
  };

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await fetch('/api/user/me'); // Changed to /api/user/me
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data: UserData = await response.json();
        setUserData(data);
        // Also update the global user state if it's different
        if (JSON.stringify(user) !== JSON.stringify(data)) {
          updateUserProfile(data);
        }
      } catch (error) {
        console.error("Failed to fetch user data:", error);
        setMessage({ type: 'error', text: 'Failed to load user data.' });
      }
    };

    if (user) { // Only fetch if user is authenticated
      fetchUserData();
    }
  }, [user, updateUserProfile]); // Re-run when user object or updateUserProfile changes

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('profilePicture', file);

    try {
      const response = await fetch('/api/user/upload-profile-picture', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      const updatedUserData = { ...userData, profile_picture_path: result.profilePicturePath };
      setUserData(updatedUserData as UserData);
      updateUserProfile(updatedUserData as UserData); // Update global state
      setSuccessMessage(result.message || 'Profile picture uploaded successfully!');
      setIsSuccessModalOpen(true);
    } catch (error: any) {
      console.error("Failed to upload profile picture:", error);
      setMessage({ type: 'error', text: error.message || 'Failed to upload profile picture.' });
    }
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleRemovePicture = async () => {
    try {
      const response = await fetch('/api/user/remove-profile-picture', {
        method: 'DELETE',
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      const updatedUserData = { ...userData, profile_picture_path: null };
      setUserData(updatedUserData as UserData);
      updateUserProfile(updatedUserData as UserData); // Update global state
      setSuccessMessage(result.message || 'Profile picture removed successfully!');
      setIsSuccessModalOpen(true);
    } catch (error: any) {
      console.error("Failed to remove profile picture:", error);
      setMessage({ type: 'error', text: error.message || 'Failed to remove profile picture.' });
    }
  };

  const handleChangePassword = async (currentPassword: string, newPassword: string) => {
    try {
      const response = await fetch('/api/user/change-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ currentPassword, newPassword }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      setSuccessMessage(result.message || 'Password updated successfully!');
      setIsSuccessModalOpen(true); // Open success modal
      setIsChangePasswordModalOpen(false); // Close change password modal
    } catch (error: any) {
      console.error("Failed to change password:", error);
      setMessage({ type: 'error', text: error.message || 'Failed to change password.' });
      throw error; // Re-throw to be caught by the modal's handleSubmit
    }
  };

  const openChangePasswordModal = () => {
    setIsChangePasswordModalOpen(true);
    setMessage(null); // Clear any previous messages
  };

  const closeChangePasswordModal = () => {
    setIsChangePasswordModalOpen(false);
  };

  const closeSuccessModal = () => {
    setIsSuccessModalOpen(false);
    setSuccessMessage('');
  };

  return (
    <div className="account-container">

      {message && (
        <div className={`message ${message.type}`}>
          {message.text}
        </div>
      )}

      

      <div className="card">
        <h2>Account Details</h2>
        <div className="subtitle">
          Manage your account details—including name, ID, and email—effortlessly in one secure place.
        </div>
        <div className="profile-section">
          <div className="avatar">
            <img src={userData?.profile_picture_path ? `/uploads/profile_pictures/${userData.profile_picture_path}` : '/default.jpeg'} alt="Profile" />
          </div>
          <div className="profile-buttons">
            <input type="file" ref={fileInputRef} onChange={handleFileChange} style={{ display: 'none' }} accept="image/*" />
            <button onClick={handleUploadClick}>
              <span></span> Upload Photo
            </button>
            <button onClick={handleRemovePicture}>
              <span>️</span> Remove
            </button>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="section-title">Basic Information</div>
        <div className="basic-info-grid">
          <div className="form-group">
            <label htmlFor="name">NAME</label>
            <input 
              type="text" 
              id="name" 
              value={userData?.name || ''} 
              readOnly={true} 
            />
          </div>
          <div className="form-group">
            <label htmlFor="role">ROLE</label>
            <input 
              type="text" 
              id="role" 
              value={userData?.role || ''} 
              readOnly={true} 
            />
          </div>
          <div className="form-group">
            <label htmlFor="email">EMAIL</label>
            <input 
              type="email" 
              id="email" 
              value={userData?.email || ''} 
              readOnly={true} 
            />
          </div>
          <div className="form-group">
            <label htmlFor="phone">PHONE NO.</label>
            <input 
              type="text" 
              id="phone" 
              value={userData?.phone || ''} 
              readOnly={true} 
            />
          </div>
        </div>
        <div style={{ clear: 'both' }}></div>
      </div>

      <div className="card change-password-section">
        <div className="section-title">Change Password</div>
        <div style={{ fontSize: '0.97rem', color: '#444', marginBottom: '10px' }}>
          To keep your account secure, please remember to update your password regularly.
        </div>
        <div style={{ fontSize: '0.97rem', color: '#444' }}>
          Click the 'Change Password' button below to set a new password.
        </div>
        <button className="change-password-btn" onClick={openChangePasswordModal}>Change Password</button>
        <div style={{ clear: 'both' }}></div>
      </div>

      {(user?.role === 'Administrator' || user?.role === 'Music Dean') && (
        <div className="card add-user-section">
          <div className="section-title">User Management</div>
          <div style={{ fontSize: '0.97rem', color: '#444', marginBottom: '10px' }}>
            Click below to add a new user to the system.
          </div>
          <button className="change-password-btn" onClick={() => setIsAddUserModalOpen(true)}>
            Add New User
          </button>
          <div style={{ clear: 'both' }}></div>
        </div>
      )}

      {isChangePasswordModalOpen && (
        <ChangePasswordModal 
          onClose={closeChangePasswordModal} 
          onPasswordChange={handleChangePassword} 
        />
      )}

      {isSuccessModalOpen && (
        <SuccessMessageModal 
          message={successMessage} 
          onClose={closeSuccessModal} 
        />
      )}

      {isFailureModalOpen && (
        <GenericFailureModal
          message={failureMessage}
          onClose={() => setIsFailureModalOpen(false)}
        />
      )}

      {isAddUserModalOpen && (
        <AddUserModal
          onClose={() => setIsAddUserModalOpen(false)}
          onUserAdded={handleAddUserMessage}
        />
      )}
    </div>
  );
};

export default Account;

      