import React, { useEffect, useState, useMemo } from 'react';
import styles from './ui_css/InventoryPage.module.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faExclamationCircle } from '@fortawesome/free-solid-svg-icons';
import AddEquipmentModal from './modals/AddEquipmentModal';
import { useAuth } from './login/AuthProvider'; // Import useAuth
import { Pie } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import ChartDataLabels from 'chartjs-plugin-datalabels';
import { PaginationControl } from './ui/PaginationControl';

ChartJS.register(ArcElement, Tooltip, Legend, ChartDataLabels);

interface InventoryItem {
  instrument_id: number;
  instrument_no: number;
  instrument_type: string;
  status: string;
  barcode: string | null;
  brand: string | null;
  description: string | null;
  image_url: string | null;
  first_name: string | null;
  last_name: string | null;
  year: number | null;
  sec: string | null;
  booking_date: string | null;
  time_in: string | null;
  rfid_uid: string | null;
  item_category: string;
}

const Inventory: React.FC = () => {
  const { user } = useAuth(); // Get user from useAuth
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [isAddEquipmentModalOpen, setIsAddEquipmentModalOpen] = useState(false);
  const [selectedInstrument, setSelectedInstrument] = useState<InventoryItem | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategoryFilter, setActiveCategoryFilter] = useState('Instrument');
  const [selectedInstrumentType, setSelectedInstrumentType] = useState('All');
  const [selectedToolType, setSelectedToolType] = useState('All');
  const [chartTitle, setChartTitle] = useState('Instrument Status');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);

  const fetchInventory = () => {
    fetch('http://localhost:3001/api/inventory')
      .then((res) => res.json())
      .then((data) => {
        setInventory(data)
      })
      .catch((err) => console.error('Error fetching inventory:', err));
  };

  useEffect(() => {
    fetchInventory();
  }, []);

  const instrumentChartData = useMemo(() => {
    let instrumentInventory = inventory.filter(item => item.item_category === 'instrument');
    if (selectedInstrumentType !== 'All') {
      instrumentInventory = instrumentInventory.filter(item => item.instrument_type === selectedInstrumentType);
    }
    const statusCounts = instrumentInventory.reduce((acc, item) => {
      acc[item.status] = (acc[item.status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const data = {
      labels: ['Available', 'Borrowed', 'Under Repair'],
      datasets: [
        {
          label: 'Instrument Status',
          data: [
            statusCounts['Available'] || 0,
            statusCounts['Borrowed'] || 0,
            statusCounts['Under Repair'] || 0,
          ],
          backgroundColor: [
            '#2E8B57',
            '#B22222',
            '#DAA520',
          ],
          borderColor: [
            '#FFFFFF',
            '#FFFFFF',
            '#FFFFFF',
          ],
          borderWidth: 2,
        },
      ],
    };
    return data;
  }, [inventory, selectedInstrumentType]);

  const toolChartData = useMemo(() => {
    let toolInventory = inventory.filter(item => item.item_category === 'tool');
    if (selectedToolType !== 'All') {
      toolInventory = toolInventory.filter(item => item.instrument_type === selectedToolType);
    }
    const statusCounts = toolInventory.reduce((acc, item) => {
      acc[item.status] = (acc[item.status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const data = {
      labels: ['Available', 'Borrowed', 'Under Repair'],
      datasets: [
        {
          label: 'Tool Status',
          data: [
            statusCounts['Available'] || 0,
            statusCounts['Borrowed'] || 0,
            statusCounts['Under Repair'] || 0,
          ],
          backgroundColor: [
            '#4682B4',
            '#FF6347',
            '#FFD700',
          ],
          borderColor: [
            '#FFFFFF',
            '#FFFFFF',
            '#FFFFFF',
          ],
          borderWidth: 2,
        },
      ],
    };
    return data;
  }, [inventory, selectedToolType]);

  const chartOptions = {
    plugins: {
      legend: {
        position: 'top' as const,
      },
      datalabels: {
        formatter: (value: number, ctx: any) => {
          const total = ctx.chart.data.datasets[0].data.reduce((a: number, b: number) => a + b, 0);
          const percentage = total > 0 ? ((value / total) * 100).toFixed(2) + '%' : '0%';
          return percentage;
        },
        color: '#fff',
        font: {
          weight: 'bold' as const,
        },
      },
    },
  };

  const openDetailsModal = (instrument: InventoryItem) => {
    setSelectedInstrument(instrument);
    setIsDetailsModalOpen(true);
  };

  const closeDetailsModal = () => {
    setSelectedInstrument(null);
    setIsDetailsModalOpen(false);
  };

  const handleSuccess = () => {
    fetchInventory();
    setIsAddEquipmentModalOpen(false);
  };

  const handleCategoryFilterClick = (filter: string) => {
    setActiveCategoryFilter(filter);
    setSelectedInstrumentType('All'); // Reset dropdowns when category changes
    setSelectedToolType('All');
    setCurrentPage(1);
    setChartTitle(`${filter} Status`);
  };

  const handleInstrumentTypeChange = (type: string) => {
    setSelectedInstrumentType(type);
    setActiveCategoryFilter('Instrument'); // Ensure Instrument category is active
    setCurrentPage(1);
    if (type === 'All') {
      setChartTitle('Instrument Status');
    } else {
      setChartTitle(`${type} Status`);
    }
  };

  const handleToolTypeChange = (type: string) => {
    setSelectedToolType(type);
    setActiveCategoryFilter('Tools'); // Ensure Tools category is active
    setCurrentPage(1);
    if (type === 'All') {
      setChartTitle('Tool Status');
    } else {
      setChartTitle(`${type} Status`);
    }
  };

  const filteredInventory = useMemo(() => {
    let filtered = inventory;

    if (activeCategoryFilter === 'Instrument') {
      filtered = filtered.filter(item => item.item_category === 'instrument');
    } else if (activeCategoryFilter === 'Tools') {
      filtered = filtered.filter(item => item.item_category === 'tool');
    }

    if (activeCategoryFilter === 'Instrument' && selectedInstrumentType !== 'All') {
      filtered = filtered.filter(item => item.instrument_type === selectedInstrumentType);
    } else if (activeCategoryFilter === 'Tools' && selectedToolType !== 'All') {
      filtered = filtered.filter(item => item.instrument_type === selectedToolType);
    }

    if (searchQuery) {
      const searchLower = searchQuery.toLowerCase();
      filtered = filtered.filter((item) => {
        return (
          item.instrument_no.toString().toLowerCase().includes(searchLower) ||
          item.instrument_type.toLowerCase().includes(searchLower) ||
          (item.barcode && item.barcode.toLowerCase().includes(searchLower)) ||
          (item.first_name && item.first_name.toLowerCase().includes(searchLower)) ||
          (item.last_name && item.last_name.toLowerCase().includes(searchLower)) ||
          (item.status && item.status.toLowerCase().includes(searchLower))
        );
      });
    }
    return filtered;
  }, [inventory, searchQuery, activeCategoryFilter, selectedInstrumentType, selectedToolType]);

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filteredInventory.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(filteredInventory.length / itemsPerPage);

  return (
    <div className={styles.container}>
      <h1>Inventory</h1>
      <p className={styles.description}>Manage all musical instruments and tools, track their status, and oversee their availability and usage.</p>
      
      <section className={styles.filtersBox} aria-label="Filters">
        <div className={styles.filtersHeader}>
          <span className={styles.iconPink}>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="size-6">
              <path d="M18.75 12.75h1.5a.75.75 0 0 0 0-1.5h-1.5a.75.75 0 0 0 0 1.5ZM12 6a.75.75 0 0 1 .75-.75h7.5a.75.75 0 0 1 0 1.5h-7.5A.75.75 0 0 1 12 6ZM12 18a.75.75 0 0 1 .75-.75h7.5a.75.75 0 0 1 0 1.5h-7.5A.75.75 0 0 1 12 18ZM3.75 6.75h1.5a.75.75 0 1 0 0-1.5h-1.5a.75.75 0 0 0 0 1.5ZM5.25 18.75h-1.5a.75.75 0 0 1 0-1.5h1.5a.75.75 0 0 1 0 1.5ZM3 12a.75.75 0 0 1 .75-.75h7.5a.75.75 0 0 1 0 1.5h-7.5A.75.75 0 0 1 3 12ZM9 3.75a2.25 2.25 0 1 0 0 4.5 2.25 2.25 0 0 0 0-4.5ZM12.75 12a2.25 2.25 0 1 1 4.5 0 2.25 2.25 0 0 1-4.5 0ZM9 15.75a2.25 2.25 0 1 0 0 4.5 2.25 2.25 0 0 0 0-4.5Z" />
            </svg>
          </span>
          Filters:
        </div>
        <div className={styles.filterButtons} role="group" aria-label="Filter by category">
          <button className={`${styles.filterBtn} ${activeCategoryFilter === 'Instrument' ? styles.active : ''}`} onClick={() => handleCategoryFilterClick('Instrument')}>Instrument</button>
          <button className={`${styles.filterBtn} ${activeCategoryFilter === 'Tools' ? styles.active : ''}`} onClick={() => handleCategoryFilterClick('Tools')}>Tools</button>
        </div>
        <form className={styles.filterForm} aria-label="Filter form">
          {activeCategoryFilter === 'Instrument' && (
            <div className={styles.filterGroup}>
              <label htmlFor="instrument-type">Instrument type</label>
              <div className={styles.customSelectWrapper}>
                <select id="instrument-type" name="instrument-type" className={styles.customSelect} onChange={(e) => handleInstrumentTypeChange(e.target.value)} value={selectedInstrumentType}>
                  <option>All</option>
                  {Array.from(new Set(inventory.filter(item => item.item_category === 'instrument').map(item => item.instrument_type))).map(type => (
                    <option key={type}>{type}</option>
                  ))}
                </select>
              </div>
            </div>
          )}
          {activeCategoryFilter === 'Tools' && (
            <div className={styles.filterGroup}>
              <label htmlFor="tool-type">Tool type</label>
              <div className={styles.customSelectWrapper}>
                <select id="tool-type" name="tool-type" className={styles.customSelect} onChange={(e) => handleToolTypeChange(e.target.value)} value={selectedToolType}>
                  <option>All</option>
                  {Array.from(new Set(inventory.filter(item => item.item_category === 'tool').map(item => item.instrument_type))).map(type => (
                    <option key={type}>{type}</option>
                  ))}
                </select>
              </div>
            </div>
          )}
        </form>
      </section>

      <div className={styles.chartsContainer}>
        {activeCategoryFilter === 'Instrument' && (
          <div className={styles.chartWrapper}>
            <h3 className={styles.chartTitle}>{chartTitle}</h3>
            <Pie data={instrumentChartData} options={chartOptions} />
          </div>
        )}
        {activeCategoryFilter === 'Tools' && (
          <div className={styles.chartWrapper}>
            <h3 className={styles.chartTitle}>{chartTitle}</h3>
            <Pie data={toolChartData} options={chartOptions} />
          </div>
        )}
      </div>

      <div className={styles.actionButtons}>
        {user?.role !== 'Student Assistant' && (
          <button className={`${styles.btn} ${styles.btnAdd}`} onClick={() => setIsAddEquipmentModalOpen(true)}>Add Equipment</button>
        )}
      </div>

      <input 
        type="text" 
        placeholder="Search..." 
        className={styles.searchBox} 
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
      />

      <div className={styles.tableContainer}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>EQUIPMENT NO.</th>
              <th>EQUIPMENT</th>
              <th>BARCODE</th>
              <th>STATUS</th>
              <th>OCCUPANT NAME</th>
              <th>YR & SEC</th>
              <th>DATE</th>
              <th>TIME</th>
              <th>BORROW REFERENCE</th>
            </tr>
          </thead>
          <tbody>
            {currentItems.map((item) => (
              <tr key={`${item.item_category}-${item.instrument_id}`}>
                <td>{item.instrument_no}</td>
                <td>{item.instrument_type}</td>
                <td>
                  <div className={styles.barcodeContainer}>
                    <span>{item.barcode || '-'}</span>
                    <FontAwesomeIcon icon={faExclamationCircle} className={styles.detailsIcon} onClick={() => openDetailsModal(item)} />
                  </div>
                </td>
                <td>
                  <span className={`${styles.statusIcon} ${item.status === 'Borrowed' ? styles.statusRed : item.status === 'Under Repair' ? styles.statusYellow : item.status === 'Decommissioned' ? styles.statusGray : styles.statusGreen}`}></span>
                  {item.status}
                </td>
                <td>{item.first_name && item.last_name ? `${item.first_name} ${item.last_name}` : '-'}</td>
                <td>{item.year && item.sec ? `${item.year}-${item.sec}` : '-'}</td>
                <td>{item.booking_date ? new Date(item.booking_date).toLocaleDateString() : '-'}</td>
                <td>{item.time_in ? new Date(item.time_in).toLocaleTimeString() : '-'}</td>
                <td>{item.rfid_uid || '-'}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <PaginationControl
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={setCurrentPage}
        />
      </div>

      {isDetailsModalOpen && selectedInstrument && (
        <div className={styles.modalOverlay}>
          <div className={styles.modal}>
            <h2>{selectedInstrument.instrument_type} #{selectedInstrument.instrument_no} Details</h2>
            {selectedInstrument.image_url && <img src={`http://localhost:3001${selectedInstrument.image_url}`} alt={`${selectedInstrument.instrument_type} #${selectedInstrument.instrument_no}`} className={styles.instrumentImage} />}
            <p><strong>Brand:</strong> {selectedInstrument.brand || 'N/A'}</p>
            <p><strong>Description:</strong> {selectedInstrument.description || 'N/A'}</p>
            <button onClick={closeDetailsModal} className={styles.detailsModalCloseBtn}>Close</button>
          </div>
        </div>
      )}

      {isAddEquipmentModalOpen && (
        <AddEquipmentModal
          onClose={() => setIsAddEquipmentModalOpen(false)}
          onSuccess={handleSuccess}
        />
      )}
    </div>
  );
};

export default Inventory;
