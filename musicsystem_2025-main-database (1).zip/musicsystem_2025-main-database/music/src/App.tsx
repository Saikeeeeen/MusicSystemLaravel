import React, { useState, useEffect } from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import './App.css';
import Sidebar from './components/Sidebar';
import TopNav from './components/TopNav';
import Dashboard from './components/Dashboard';
import Resources from './components/Resources';
import ActivityLog from './components/ActivityLog';
import Reports from './components/Reports';
import StudentInformation from './components/StudentInformation';
import Inventory from './components/Inventory';
import ManageEquipment from './components/ManageEquipment';
import Account from './components/Account';
import Login from './components/login/Login';
import { useAuth } from './components/login/AuthProvider';
import ProtectedRoute from './components/login/ProtectedRoute';
import RedirectIfAuth from './components/login/RedirectIfAuth'; // Import the new component


const App: React.FC = () => {
  const { user } = useAuth();
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false); // New state for modal
  const location = useLocation();

  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const handleResize = () => {
    if (window.innerWidth <= 768) {
      setIsSidebarCollapsed(true);
    } else {
      setIsSidebarCollapsed(false);
    }
  };

  useEffect(() => {
    window.addEventListener('resize', handleResize);
    handleResize(); // Call on initial render
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="App">
        {user && location.pathname !== '/login' && (
          <>
            <Sidebar toggleSidebar={toggleSidebar} isCollapsed={isSidebarCollapsed} setIsModalOpen={setIsModalOpen} />
            <TopNav isCollapsed={isSidebarCollapsed} toggleSidebar={toggleSidebar} isModalOpen={isModalOpen} />
          </>
        )}
        <main className={`main-content ${location.pathname === '/login' ? 'main-content-full-width' : (isSidebarCollapsed ? 'main-content-collapsed' : '')} ${location.pathname !== '/login' ? 'main-content-transition' : ''}`}>
          <Routes>
            {/* The login route is now protected by RedirectIfAuth */}
            <Route path="/login" element={<RedirectIfAuth><Login /></RedirectIfAuth>} />
            
            <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
            <Route path="/resources" element={<ProtectedRoute><Resources /></ProtectedRoute>} />
            <Route path="/activity-log" element={<ProtectedRoute><ActivityLog /></ProtectedRoute>} />
            <Route path="/reports" element={<ProtectedRoute><Reports /></ProtectedRoute>} />
            <Route path="/student-information" element={<ProtectedRoute><StudentInformation /></ProtectedRoute>} />
            <Route path="/inventory" element={<ProtectedRoute><Inventory /></ProtectedRoute>} />
            <Route path="/manage-equipment" element={<ProtectedRoute><ManageEquipment /></ProtectedRoute>} />
            <Route path="/account" element={<ProtectedRoute><Account /></ProtectedRoute>} />

            <Route path="*" element={user ? <Navigate to="/dashboard" /> : <Navigate to="/login" />} />
          </Routes>
        </main>
      </div>
  );
};

export default App;