/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
    "./src/components/**/*.{js,ts,jsx,tsx}", // Added to ensure Shadcn components are scanned
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
