import express from 'express';
import db from './database.js';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import cookieParser from 'cookie-parser'; // Import cookie-parser
import multer from 'multer';
import path from 'path';
import instrumentRoutes from './routes/instruments.js';
import toolRoutes from './routes/tools.js';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const port = 3001;

// IMPORTANT: In a real app, use environment variables for the secret and CORS origin
const JWT_SECRET = process.env.JWT_SECRET;
const CORS_ORIGIN = ["http://localhost:5173", "http://localhost:5174"]; // Your Vite frontend URL

if (!JWT_SECRET) {
  console.error('FATAL ERROR: JWT_SECRET is not defined.');
  process.exit(1);
}

app.use(cors({
  origin: 'http://localhost:5173',
  credentials: true, // Allow cookies to be sent from the frontend
}));
app.use(express.json());
app.use(express.static('public'));
app.use(cookieParser()); // Use cookie-parser middleware
app.use('/uploads', express.static('public/uploads'));

// Multer storage configuration
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'public/uploads/profile_pictures');
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });

// Middleware to protect routes
const authenticateToken = (req, res, next) => {
  const token = req.cookies.token;

  if (!token) {
    return res.status(401).json({ message: 'Authentication token missing' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      console.error('JWT verification error:', err);
      return res.status(403).json({ message: 'Invalid or expired token' });
    }
    req.user = user; // Attach user payload to the request
    next();
  });
};

const authorizeRoles = (...allowedRoles) => {
  return (req, res, next) => {
    if (!req.user || !allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ message: 'You do not have permission to perform this action.' });
    }
    next();
  };
};

// New endpoint to get authenticated user's profile
app.get('/api/user/me', authenticateToken, (req, res) => {
  const userId = req.user.id;

  const sql = 'SELECT id, name, email, phone, role, profile_picture_path FROM users WHERE id = ?';
  db.query(sql, [userId], (err, results) => {
    if (err) {
      if (err.code === 'ER_BAD_FIELD_ERROR') {
        const fallbackSql = 'SELECT id, name, email, phone FROM users WHERE id = ?';
        db.query(fallbackSql, [userId], (fallbackErr, fallbackResults) => {
          if (fallbackErr) {
            console.error('Error fetching user profile (fallback):', fallbackErr);
            return res.status(500).json({ message: 'Internal server error' });
          }
          if (fallbackResults.length === 0) {
            return res.status(404).json({ message: 'User not found' });
          }
          const userProfile = {
            ...fallbackResults[0],
            role: 'user',
            profile_picture_path: null,
          };
          res.json(userProfile);
        });
      } else {
        console.error('Error fetching user profile:', err);
        return res.status(500).json({ message: 'Internal server error' });
      }
    } else {
      if (results.length === 0) {
        return res.status(404).json({ message: 'User not found' });
      }
      res.json(results[0]);
    }
  });
});

import fs from 'fs'; // Import fs for file system operations

app.post('/api/user/upload-profile-picture', authenticateToken, upload.single('profilePicture'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ message: 'No file uploaded.' });
  }

  const userId = req.user.id;
  const newProfilePicturePath = path.basename(req.file.path); // Just the filename

  // First, get the old profile picture path from the database
  const getOldPathSql = 'SELECT profile_picture_path FROM users WHERE id = ?';
  db.query(getOldPathSql, [userId], (err, results) => {
    if (err) {
      console.error('Error fetching old profile picture path:', err);
      return res.status(500).json({ message: 'Internal server error.' });
    }

    const oldProfilePicturePath = results[0]?.profile_picture_path;

    // Update the user's profile_picture_path in the database
    const updateSql = 'UPDATE users SET profile_picture_path = ? WHERE id = ?';
    db.query(updateSql, [newProfilePicturePath, userId], (err, result) => {
      if (err) {
        console.error('Error updating profile picture path in DB:', err);
        // If DB update fails, delete the newly uploaded file to prevent orphaned files
        fs.unlink(req.file.path, (unlinkErr) => {
          if (unlinkErr) console.error('Error deleting newly uploaded file after DB error:', unlinkErr);
        });
        return res.status(500).json({ message: 'Failed to update profile picture.' });
      }

      // If there was an old profile picture, delete it from the file system
      if (oldProfilePicturePath) {
        const fullOldPath = path.join('public/uploads/profile_pictures', oldProfilePicturePath);
        fs.unlink(fullOldPath, (unlinkErr) => {
          if (unlinkErr) console.error('Error deleting old profile picture:', unlinkErr);
        });
      }

      res.json({
        message: 'Profile picture uploaded successfully!',
        profilePicturePath: newProfilePicturePath
      });
    });
  });
});

app.delete('/api/user/remove-profile-picture', authenticateToken, (req, res) => {
  const userId = req.user.id;

  // Get the current profile picture path from the database
  const getPathSql = 'SELECT profile_picture_path FROM users WHERE id = ?';
  db.query(getPathSql, [userId], (err, results) => {
    if (err) {
      console.error('Error fetching profile picture path for removal:', err);
      return res.status(500).json({ message: 'Internal server error.' });
    }

    const profilePicturePath = results[0]?.profile_picture_path;

    // Update the user's profile_picture_path to NULL in the database
    const updateSql = 'UPDATE users SET profile_picture_path = NULL WHERE id = ?';
    db.query(updateSql, [userId], (err, result) => {
      if (err) {
        console.error('Error setting profile picture path to NULL in DB:', err);
        return res.status(500).json({ message: 'Failed to remove profile picture.' });
      }

      // If a profile picture existed, delete the physical file
      if (profilePicturePath) {
        const fullPath = path.join('public/uploads/profile_pictures', profilePicturePath);
        fs.unlink(fullPath, (unlinkErr) => {
          if (unlinkErr) console.error('Error deleting profile picture file:', unlinkErr);
        });
      }

      res.json({ message: 'Profile picture removed successfully!' });
    });
  });
});

app.post('/api/admin/add-user', authenticateToken, authorizeRoles('Administrator', 'Music Dean'), async (req, res) => {
  const { name, email, password, role, phone } = req.body;

  if (!name || !email || !password || !role) {
    return res.status(400).json({ message: 'Name, email, password, and role are required.' });
  }

  // Basic email format validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ message: 'Invalid email format.' });
  }

  // Password strength (example: min 6 characters)
  if (password.length < 6) {
    return res.status(400).json({ message: 'Password must be at least 6 characters long.' });
  }

  // Validate role
  const allowedRoles = ['Administrator', 'Music Dean', 'Student Assistant'];
  if (!allowedRoles.includes(role)) {
    return res.status(400).json({ message: 'Invalid role specified.' });
  }

  try {
    // Check if email already exists
    const checkEmailSql = 'SELECT id FROM users WHERE email = ?';
    db.query(checkEmailSql, [email], async (err, results) => {
      if (err) {
        console.error('Error checking existing email:', err);
        return res.status(500).json({ message: 'Internal server error.' });
      }
      if (results.length > 0) {
        return res.status(409).json({ message: 'User with this email already exists.' });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);

      // Insert new user
      const insertUserSql = 'INSERT INTO users (name, email, password, role, phone) VALUES (?, ?, ?, ?, ?)';
      db.query(insertUserSql, [name, email, hashedPassword, role, phone], (err, result) => {
        if (err) {
          console.error('Error inserting new user:', err);
          return res.status(500).json({ message: 'Internal server error.' });
        }
        res.status(201).json({ message: 'User added successfully!', userId: result.insertId });
      });
    });
  } catch (error) {
    console.error('Error in add-user route:', error);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

app.post('/api/login', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password are required' });
  }

  const sql = 'SELECT id, email, password, name, role, profile_picture_path FROM users WHERE email = ?';
  db.query(sql, [email], (err, results) => {
    if (err) {
      if (err.code === 'ER_BAD_FIELD_ERROR') {
        const fallbackSql = 'SELECT id, email, password, name FROM users WHERE email = ?';
        db.query(fallbackSql, [email], (fallbackErr, fallbackResults) => {
          if (fallbackErr) {
            console.error('Error fetching user (fallback):', fallbackErr);
            return res.status(500).json({ message: 'Internal server error' });
          }
          handleLoginResponse(req, res, fallbackResults, password, true);
        });
      } else {
        console.error('Error fetching user:', err);
        return res.status(500).json({ message: 'Internal server error' });
      }
    } else {
      handleLoginResponse(req, res, results, password, false);
    }
  });
});

function handleLoginResponse(req, res, results, password, isFallback) {
  if (results.length === 0) {
    return res.status(401).json({ message: 'Invalid email or password' });
  }

  const user = results[0];

  bcrypt.compare(password, user.password, (err, isMatch) => {
    if (err) {
      console.error('Error comparing passwords:', err);
      return res.status(500).json({ message: 'Internal server error' });
    }

    if (isMatch) {
      const tokenPayload = {
        id: user.id,
        email: user.email,
        name: user.name,
        role: isFallback ? 'user' : user.role,
        profile_picture_path: isFallback ? null : user.profile_picture_path
      };
      const token = jwt.sign(tokenPayload, JWT_SECRET, { expiresIn: '1d' });

      res.cookie('token', token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 24 * 60 * 60 * 1000 // 1 day
      });

      res.json({
        id: user.id,
        email: user.email,
        name: user.name,
        role: isFallback ? 'user' : user.role,
        profile_picture_path: isFallback ? null : user.profile_picture_path
      });
    } else {
      res.status(401).json({ message: 'Invalid email or password' });
    }
  });
}

// New endpoint to verify the session on page load
app.get('/api/verify-session', (req, res) => {
  const token = req.cookies.token;

  if (!token) {
    return res.status(401).json({ message: 'Not authenticated' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    // Send back user info stored in the token
    res.json({ id: decoded.id, email: decoded.email, name: decoded.name, role: decoded.role, profile_picture_path: decoded.profile_picture_path });
  } catch (err) {
    console.error('JWT verification error:', err);
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
});

app.post('/api/logout', (req, res) => {
  // Clear the cookie to log the user out
  res.clearCookie('token').json({ message: 'Logout successful' });
});



app.get('/api/cubicles', (req, res) => {
  let sql = `
    SELECT 
      ci.cubicle_id, 
      ci.cubicle_type, 
      ci.cubicle_no, 
      ci.status,
      s.first_name,
      s.last_name,
      s.year,
      s.sec,
      cb.time_in
    FROM cubicle_info ci
    LEFT JOIN cubicle_bookings cb ON ci.cubicle_id = cb.cubicle_id AND cb.status = 'Active'
    LEFT JOIN student s ON cb.student_id = s.student_id
  `;
  const params = [];

  db.query(sql, params, (err, results) => {
    if (err) {
      console.error('Error fetching cubicles:', err);
      res.status(500).send(err);
    } else {
      const formattedResults = results.map(row => ({
        cubicle_id: row.cubicle_id,
        cubicle_type: row.cubicle_type,
        cubicle_no: row.cubicle_no,
        status: row.status,
        name: row.first_name && row.last_name ? `${row.first_name} ${row.last_name}` : '-',
        yr_sec: row.year && row.sec ? `${row.year}-${row.sec}` : '-',
        time_in: row.time_in ? row.time_in : '-',
      }));
      console.log('Cubicles data fetched:', formattedResults);
      res.json(formattedResults);
    }
  });
});

app.get('/api/instruments', (req, res) => {
  let sql = `
    SELECT 
      ii.instrument_id, 
      ii.instrument_type, 
      ii.instrument_no, 
      ii.status,
      s.first_name,
      s.last_name,
      s.year,
      s.sec,
      ib.time_in
    FROM instrument_info ii
    LEFT JOIN instrument_bookings ib ON ii.instrument_id = ib.instrument_id AND ib.status = 'Active'
    LEFT JOIN student s ON ib.student_id = s.student_id
  `;
  const params = [];

  db.query(sql, params, (err, results) => {
    if (err) {
      console.error('Error fetching instruments:', err);
      res.status(500).send(err);
    } else {
      const formattedResults = results.map(row => ({
        instrument_id: row.instrument_id, 
        instrument_type: row.instrument_type, 
        instrument_no: row.instrument_no, 
        status: row.status,
        name: row.first_name && row.last_name ? `${row.first_name} ${row.last_name}` : '-',
        yr_sec: row.year && row.sec ? `${row.year}-${row.sec}` : '-',
        time_in: row.time_in ? new Date(row.time_in).toISOString() : '-',
      }));
      console.log('Instruments data fetched:', formattedResults);
      res.json(formattedResults);
    }
  });
});



app.get('/activity-log', (req, res) => {
  const { table, type, startDate, endDate } = req.query;

  let baseQuery;
  const params = [];
  let whereClauses = [];

  if (table === 'cubicles') {
    baseQuery = `
      SELECT 
        CONCAT(s.last_name, ', ', s.first_name, IF(s.middle_initial IS NOT NULL AND s.middle_initial != '', CONCAT(' ', LEFT(s.middle_initial, 1), '.'), '')) AS name,
        CONCAT(s.year, '-', s.sec) AS yr_sec,
        ci.cubicle_type AS item_type,
        ci.cubicle_no AS item_number,
        cu.start_time AS time_in,
        cu.end_time AS time_out,
        TIMESTAMPDIFF(HOUR, cu.start_time, cu.end_time) AS total_hours,
        TIMESTAMPDIFF(MINUTE, cu.start_time, cu.end_time) AS consumed_minutes
      FROM cubicle_usage cu
      JOIN student s ON cu.student_id = s.student_id
      JOIN cubicle_info ci ON cu.cubicle_id = ci.cubicle_id
    `;

    if (startDate && endDate) {
      whereClauses.push('cu.usage_date BETWEEN ? AND ?');
      params.push(startDate, endDate);
    }

    if (type && type !== 'All') {
      whereClauses.push('ci.cubicle_type = ?');
      params.push(type);
    }

  } else if (table === 'instruments') {
    baseQuery = `
      SELECT 
        CONCAT(s.last_name, ', ', s.first_name, IF(s.middle_initial IS NOT NULL AND s.middle_initial != '', CONCAT(' ', LEFT(s.middle_initial, 1), '.'), '')) AS name,
        CONCAT(s.year, '-', s.sec) AS yr_sec,
        ii.instrument_type AS item_type,
        iu.instrument_no AS item_number,
        iu.start_time AS time_in,
        iu.end_time AS time_out,
        TIMESTAMPDIFF(HOUR, iu.start_time, iu.end_time) AS total_hours,
        TIMESTAMPDIFF(MINUTE, iu.start_time, iu.end_time) AS consumed_minutes
      FROM instrument_usage iu
      JOIN student s ON iu.student_id = s.student_id
      JOIN instrument_info ii ON iu.instrument_id = ii.instrument_id
    `;

    if (startDate && endDate) {
      whereClauses.push('iu.usage_date BETWEEN ? AND ?');
      params.push(startDate, endDate);
    }

    if (type && type !== 'All') {
      whereClauses.push('ii.instrument_type = ?');
      params.push(type);
    }

  } else {
    return res.status(400).send('Invalid table type');
  }

  let query = baseQuery;
  if (whereClauses.length > 0) {
    query += ' WHERE ' + whereClauses.join(' AND ');
  }
  query += ' ORDER BY usage_date DESC, start_time DESC';

  db.query(query, params, (err, results) => {
    if (err) {
      console.error('Error fetching activity log:', err);
      res.status(500).send(err);
    } else {
      const formattedResults = results.map(row => ({
        ...row,
        time_in: row.time_in ? new Date(row.time_in).toISOString() : null,
        time_out: row.time_out ? new Date(row.time_out).toISOString() : null,
      }));
      console.log('Activity log data fetched:', formattedResults);
      res.json(formattedResults);
    }
  });
});

app.post('/api/students', (req, res) => {
  console.log(req.body);
  const { rfid_uid, student_id, first_name, middle_initial, last_name, year, sec } = req.body;
  const sql = 'INSERT INTO student (rfid_uid, student_id, first_name, middle_initial, last_name, year, sec) VALUES (?, ?, ?, ?, ?, ?, ?)';
  const values = [rfid_uid, student_id, first_name, middle_initial, last_name, year, sec];

  db.query(sql, values, (err, result) => {
    if (err) {
      console.error('Error adding student:', err);
      res.status(500).json({ message: 'Failed to add student', error: err.message });
    } else {
      const newStudent = {
        id: result.insertId,
        rfid_uid,
        student_id,
        first_name,
        middle_initial,
        last_name,
        year,
        sec,
      };
      console.log('Student added:', newStudent);
      res.status(201).json(newStudent);
    }
  });
});

app.get('/api/students', (req, res) => {
  const sql = 'SELECT student_id, first_name, middle_initial, last_name, year, sec, mtl_time_remaining FROM student';
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error fetching students:', err);
      res.status(500).send(err);
    } else {
      console.log('Students data fetched:', results);
      res.json(results);
    }
  });
});

app.post('/api/validate-student', (req, res) => {
  const { studentIdOrRfid } = req.body;
  const sql = 'SELECT student_id, first_name, last_name, rfid_uid, mtl_time_remaining FROM student WHERE student_id = ? OR rfid_uid = ?';
  db.query(sql, [studentIdOrRfid, studentIdOrRfid], (err, results) => {
    if (err) {
      console.error('Error validating student:', err);
      return res.status(500).json({ message: 'Internal server error.' });
    }
    if (results.length > 0) {
      res.status(200).json({ message: 'Student found.', student: results[0] });
    } else {
      res.status(404).json({ message: 'Student not found.' });
    }
  });
});

app.post('/api/book', (req, res) => {
  const { cubicle_id, student_id } = req.body;
  const now = new Date();
  const time_in = now.toISOString().slice(0, 19).replace('T', ' '); // Store as UTC
  const booking_date = time_in.slice(0, 10); // Extract date from the UTC time_in

  db.beginTransaction(err => {
    if (err) {
      console.error('Error starting transaction:', err);
      return res.status(500).json({ message: 'Internal server error.' });
    }

    // 1. Get cubicle_type from cubicle_info and student's mtl_time_remaining
    const getInfoSql = 'SELECT ci.cubicle_type, ci.cubicle_no, s.mtl_time_remaining FROM cubicle_info ci JOIN student s ON s.student_id = ? WHERE ci.cubicle_id = ?';
    db.query(getInfoSql, [student_id, cubicle_id], (err, results) => {
      if (err) {
        return db.rollback(() => {
          console.error('Error fetching cubicle info or student time:', err);
          res.status(500).json({ message: 'Internal server error.' });
        });
      }
      if (results.length === 0) {
        return db.rollback(() => {
          res.status(404).json({ message: 'Cubicle or student not found.' });
        });
      }

      const { cubicle_type, cubicle_no, mtl_time_remaining } = results[0];
      let new_mtl_time_remaining = mtl_time_remaining;

      // Handles MTL cubicle booking logic
      if (cubicle_type === 'MTL') {
        if (mtl_time_remaining <= 0) {
          return db.rollback(() => {
            res.status(400).json({ message: 'No MTL session time remaining.' });
          });
        }
        // Deduction of MTL time will now happen on timeout
        proceedBooking();
      } else {
        proceedBooking();
      }

      function proceedBooking() {
        // Insert into cubicle_bookings (for active tracking)
        const insertBookingSql = 'INSERT INTO cubicle_bookings (student_id, cubicle_id, cubicle_no, cubicle_type, booking_date, time_in, status) VALUES (?, ?, ?, ?, ?, ?, ?)';
        db.query(insertBookingSql, [student_id, cubicle_id, cubicle_no, cubicle_type, booking_date, time_in, 'Active'], (err, bookingResult) => {
          if (err) {
            return db.rollback(() => {
              console.error('Error inserting into cubicle_bookings:', err);
              res.status(500).json({ message: 'Internal server error during booking insertion.' });
            });
          }

          // Insert into cubicle_usage (for historical tracking)
          const insertUsageSql = 'INSERT INTO cubicle_usage (student_id, cubicle_id, usage_date, start_time, end_time) VALUES (?, ?, ?, ?, NULL)';
          db.query(insertUsageSql, [student_id, cubicle_id, booking_date, time_in], (err, usageResult) => {
            if (err) {
              return db.rollback(() => {
                console.error('Error inserting into cubicle_usage:', err);
                res.status(500).json({ message: 'Internal server error during usage insertion.' });
              });
            }

            // Update cubicle_info status to 'Occupied'
            const updateCubicleStatusSql = 'UPDATE cubicle_info SET status = ? WHERE cubicle_id = ?';
            db.query(updateCubicleStatusSql, ['Occupied', cubicle_id], (err, updateResult) => {
              if (err) {
                return db.rollback(() => {
                  console.error('Error updating cubicle status:', err);
                  res.status(500).json({ message: 'Internal server error during status update.' });
                });
              }

              // Insert into cubicle_usage_logs (for activity log)
              const insertLogSql = 'INSERT INTO cubicle_usage_logs (cubicle_id, cubicle_no, cubicle_type, usage_date, student_id) VALUES (?, ?, ?, ?, ?)';
              db.query(insertLogSql, [cubicle_id, cubicle_no, cubicle_type, booking_date, student_id], (err, logResult) => {
                if (err) {
                  return db.rollback(() => {
                    console.error('Error inserting into cubicle_usage_logs:', err);
                    res.status(500).json({ message: 'Internal server error during log insertion.' });
                  });
                }

                db.commit(err => {
                  if (err) {
                    return db.rollback(() => {
                      console.error('Error committing transaction:', err);
                      res.status(500).json({ message: 'Internal server error during transaction commit.' });
                    });
                  }
                  res.status(201).json({ message: 'Booking successful!', booking_id: bookingResult.insertId });
                });
              });
            });
          });
        });
      }
    });
  });
});

app.get('/api/available-cubicles', (req, res) => {
  const sql = 'SELECT cubicle_id, cubicle_type, cubicle_no FROM cubicle_info WHERE status = "Available"';
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error fetching available cubicles:', err);
      return res.status(500).json({ message: 'Internal server error.' });
    }

    const availableCubicles = {
      Guitar: [],
      Piano: [],
      MTL: [],
    };

    results.forEach((cubicle) => {
      if (availableCubicles[cubicle.cubicle_type]) {
        availableCubicles[cubicle.cubicle_type].push(cubicle);
      }
    });
    res.status(200).json(availableCubicles);
  });
});

app.post('/api/timeout-cubicle', (req, res) => {
  const { cubicle_id } = req.body;
  const time_out = new Date();

  db.beginTransaction(err => {
    if (err) {
      console.error('Error starting transaction:', err);
      return res.status(500).json({ message: 'Internal server error.' });
    }

    // 1. Get the booking start time and student_id
    const getBookingSql = 'SELECT time_in, student_id FROM cubicle_bookings WHERE cubicle_id = ? AND status = "Active" ';
    db.query(getBookingSql, [cubicle_id], (err, results) => {
      if (err) {
        return db.rollback(() => {
          console.error('Error fetching booking:', err);
          res.status(500).json({ message: 'Internal server error during booking fetch.' });
        });
      }

      if (results.length === 0) {
        return db.rollback(() => {
          res.status(404).json({ message: 'Active booking not found for this cubicle.' });
        });
      }

      const time_in = results[0].time_in;
      const student_id = results[0].student_id;
      const duration = Math.round((time_out.getTime() - new Date(time_in).getTime()) / 60000); // in minutes
      console.log('Calculated duration (minutes):', duration); // ADDED LOG

      // Get cubicle_type and mtl_time_remaining
      const getCubicleTypeAndMtlSql = 'SELECT ci.cubicle_type, s.mtl_time_remaining FROM cubicle_info ci JOIN student s ON s.student_id = ? WHERE ci.cubicle_id = ?';
      db.query(getCubicleTypeAndMtlSql, [student_id, cubicle_id], (err, typeResults) => {
        if (err) {
          return db.rollback(() => {
            console.error('Error fetching cubicle details for timeout:', err);
            res.status(500).json({ message: 'Internal server error during cubicle details fetch.' });
          });
        }

        const proceedWithTimeoutUpdates = () => {
          // 2. Update cubicle_usage: set end_time for the active booking
          const updateUsageSql = 'UPDATE cubicle_usage SET end_time = ? WHERE cubicle_id = ? AND end_time IS NULL';
          db.query(updateUsageSql, [time_out.toISOString().slice(0, 19).replace('T', ' '), cubicle_id], (err, usageResult) => {
            if (err) {
              return db.rollback(() => {
                console.error('Error updating cubicle_usage:', err);
                res.status(500).json({ message: 'Internal server error during usage update.' });
              });
            }

            // 3. Delete from cubicle_bookings
            const deleteBookingSql = 'DELETE FROM cubicle_bookings WHERE cubicle_id = ? AND status = "Active"';
            db.query(deleteBookingSql, [cubicle_id], (err, deleteResult) => {
              if (err) {
                return db.rollback(() => {
                  console.error('Error deleting from cubicle_bookings:', err);
                  res.status(500).json({ message: 'Internal server error during booking deletion.' });
                });
              }

              // 4. Update cubicle_info: set status to 'Available'
              const updateInfoSql = 'UPDATE cubicle_info SET status = ? WHERE cubicle_id = ?';
              db.query(updateInfoSql, ['Available', cubicle_id], (err, infoResult) => {
                if (err) {
                  return db.rollback(() => {
                    console.error('Error updating cubicle_info:', err);
                    res.status(500).json({ message: 'Internal server error during info update.' });
                  });
                }

                db.commit(err => {
                  if (err) {
                    return db.rollback(() => {
                      console.error('Error committing transaction:', err);
                      res.status(500).json({ message: 'Internal server error during transaction commit.' });
                    });
                  }
                  res.status(200).json({ message: 'Cubicle successfully timed out.', duration });
                });
              });
            });
          });
        };

        if (typeResults.length > 0 && typeResults[0].cubicle_type === 'MTL') {
          const current_mtl_time_remaining = typeResults[0].mtl_time_remaining;
          console.log('Current MTL time remaining (minutes):', current_mtl_time_remaining); // ADDED LOG

          const new_mtl_time_remaining = Math.max(0, current_mtl_time_remaining - duration);
          console.log('New MTL time remaining (minutes):', new_mtl_time_remaining); // ADDED LOG

          const updateMtlSql = 'UPDATE student SET mtl_time_remaining = ? WHERE student_id = ?';
          db.query(updateMtlSql, [new_mtl_time_remaining, student_id], (err, updateMtlResult) => {
            if (err) {
              return db.rollback(() => {
                console.error('Error updating student MTL time on timeout:', err);
                res.status(500).json({ message: 'Internal server error during MTL time update.' });
              });
            }
            proceedWithTimeoutUpdates();
          });
        } else {
          proceedWithTimeoutUpdates();
        }
      });
    });
  });
});

app.delete('/api/students/:student_id', authenticateToken, authorizeRoles('admin'), (req, res) => {
  const studentId = req.params.student_id;

  db.beginTransaction(err => {
    if (err) {
      console.error('Error starting transaction:', err);
      return res.status(500).json({ message: 'Internal server error.' });
    }

    // Delete from cubicle_bookings
    const deleteCubicleBookingsSql = 'DELETE FROM cubicle_bookings WHERE student_id = ?';
    db.query(deleteCubicleBookingsSql, [studentId], (err, result) => {
      if (err) {
        return db.rollback(() => {
          console.error('Error deleting cubicle bookings:', err);
          res.status(500).json({ message: 'Failed to delete cubicle bookings.' });
        });
      }

      // Delete from cubicle_usage
      const deleteCubicleUsageSql = 'DELETE FROM cubicle_usage WHERE student_id = ?';
      db.query(deleteCubicleUsageSql, [studentId], (err, result) => {
        if (err) {
          return db.rollback(() => {
            console.error('Error deleting cubicle usage:', err);
            res.status(500).json({ message: 'Failed to delete cubicle usage.' });
          });
        }

        // Delete the student
        const deleteStudentSql = 'DELETE FROM student WHERE student_id = ?';
        db.query(deleteStudentSql, [studentId], (err, result) => {
          if (err) {
            return db.rollback(() => {
              console.error('Error deleting student:', err);
              res.status(500).json({ message: 'Failed to delete student.' });
            });
          }

          if (result.affectedRows === 0) {
            return db.rollback(() => {
              res.status(404).json({ message: 'Student not found.' });
            });
          }

          db.commit(err => {
            if (err) {
              return db.rollback(() => {
                console.error('Error committing transaction:', err);
                res.status(500).json({ message: 'Internal server error during transaction commit.' });
              });
            }
            res.status(200).json({ message: 'Student removed successfully.' });
          });
        });
      });
    });
  });
});

app.use('/', instrumentRoutes);
app.use('/', toolRoutes);

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});