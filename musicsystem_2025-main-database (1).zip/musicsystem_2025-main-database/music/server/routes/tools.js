
import express from 'express';
const router = express.Router();
import db from '../database.js';
import multer from 'multer';
import path from 'path';

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'public/uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });

router.put('/api/tools/:tool_id', upload.single('image'), (req, res) => {
  console.log("Received request to update tool:", req.params.tool_id, req.body);
  const { tool_id } = req.params;
  const { tool_no, tool_type, brand, barcode, description, status } = req.body;
  let imageUrl = req.body.image_url; // Keep existing image if not updated

  if (req.file) {
    imageUrl = `/uploads/${req.file.filename}`;
  }

  const sql = 'UPDATE tools_info SET tool_no = ?, tool_type = ?, brand = ?, barcode = ?, description = ?, status = ?, image_url = ? WHERE tool_id = ?';
  const values = [tool_no, tool_type, brand, barcode, description, status, imageUrl, tool_id];
  console.log("Executing SQL:", sql, values);

  db.query(sql, values, (err, result) => {
    if (err) {
      console.error('Error updating tool:', err);
      return res.status(500).json({ message: 'Internal server error' });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Tool not found.' });
    }
    console.log("Tool updated successfully:", result);
    res.status(200).json({ message: 'Tool updated successfully.' });
  });
});

router.delete('/api/tools/:tool_id', (req, res) => {
  const { tool_id } = req.params;

  const sql = 'DELETE FROM tools_info WHERE tool_id = ?';
  db.query(sql, [tool_id], (err, result) => {
    if (err) {
      console.error('Error deleting tool:', err);
      return res.status(500).json({ message: 'Internal server error' });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Tool not found.' });
    }
    res.status(200).json({ message: 'Tool deleted successfully.' });
  });
});

router.post('/api/tools', (req, res) => {
    console.log("Received request to add tool:", req.body);
    upload.single('image')(req, res, function (err) {
      if (err instanceof multer.MulterError) {
        return res.status(500).json({ message: err.message });
      } else if (err) {
        return res.status(500).json({ message: `An unknown error occurred: ${err.message}` });
      }
  
      const { tool_no, tool_type, barcode, brand, description } = req.body;
      const imageUrl = req.file ? `/uploads/${req.file.filename}` : null;
  
      if (!tool_no || !tool_type) {
        return res.status(400).json({ message: 'Tool number and type are required.' });
      }
  
      const sql = 'INSERT INTO tools_info (tool_no, tool_type, barcode, brand, description, image_url, status) VALUES (?, ?, ?, ?, ?, ?, ?)';
      const values = [tool_no, tool_type, barcode, brand, description, imageUrl, 'Available'];
  
      db.query(sql, values, (err, result) => {
        if (err) {
          console.error('Error adding tool:', err);
          return res.status(500).json({ message: 'Internal server error' });
        }
        console.log("Tool added successfully:", result);
        res.status(201).json({ message: 'Tool added successfully.', tool_id: result.insertId });
      });
    })
  });

export default router;
