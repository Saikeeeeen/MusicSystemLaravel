import express from 'express';
const router = express.Router();
import db from '../database.js';
import multer from 'multer';
import path from 'path';

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'public/uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });

router.post('/api/borrow-instrument', (req, res) => {
  const { student_id, instrument_id } = req.body;

  if (!student_id || !instrument_id) {
    return res.status(400).json({ message: 'Student ID and instrument ID are required.' });
  }

  // Check if student exists
  db.query('SELECT * FROM student WHERE student_id = ?', [student_id], (err, studentResults) => {
    if (err) {
      console.error('Error checking student:', err);
      return res.status(500).json({ message: 'Internal server error' });
    }

    if (studentResults.length === 0) {
      return res.status(404).json({ message: 'Student not found.' });
    }

    // Check if instrument is available
    db.query(`SELECT * FROM instrument_info WHERE instrument_id = ? AND status = 'Available'`, [instrument_id], (err, instrumentResults) => {
      if (err) {
        console.error('Error finding instrument:', err);
        return res.status(500).json({ message: 'Internal server error' });
      }

      if (instrumentResults.length === 0) {
        return res.status(400).json({ message: 'Instrument not available.' });
      }

      const instrument = instrumentResults[0];
      const instrument_no = instrument.instrument_no;
      const instrument_type = instrument.instrument_type;

      // Start a transaction
      db.beginTransaction(err => {
        if (err) {
          console.error('Error starting transaction:', err);
          return res.status(500).json({ message: 'Internal server error' });
        }

        // Insert into instrument_bookings
        const bookingQuery = `INSERT INTO instrument_bookings (student_id, instrument_id, instrument_no, instrument_type, booking_date, time_in, status) VALUES (?, ?, ?, ?, CURDATE(), UTC_TIMESTAMP(), 'Active')`;
        db.query(bookingQuery, [student_id, instrument_id, instrument_no, instrument_type], (err, bookingResult) => {
          if (err) {
            return db.rollback(() => {
              console.error('Error creating booking:', err);
              res.status(500).json({ message: 'Internal server error' });
            });
          }

          // Update instrument_info status
          const updateQuery = `UPDATE instrument_info SET status = 'Borrowed' WHERE instrument_id = ?`;
          db.query(updateQuery, [instrument_id], (err, updateResult) => {
            if (err) {
              return db.rollback(() => {
                console.error('Error updating instrument status:', err);
                res.status(500).json({ message: 'Internal server error' });
              });
            }

            // Insert into instrument_usage_logs
            const logQuery = 'INSERT INTO instrument_usage_logs (instrument_id, instrument_no, instrument_type, usage_date, student_id) VALUES (?, ?, ?, CURDATE(), ?)';
            db.query(logQuery, [instrument_id, instrument_no, instrument_type, student_id], (err, logResult) => {
              if (err) {
                return db.rollback(() => {
                  console.error('Error creating usage log:', err);
                  res.status(500).json({ message: 'Internal server error' });
                });
              }

              // Insert into instrument_usage
              const insertUsageSql = 'INSERT INTO instrument_usage (instrument_id, instrument_no, student_id, usage_date, start_time, end_time) VALUES (?, ?, ?, CURDATE(), UTC_TIMESTAMP(), NULL)';
              db.query(insertUsageSql, [instrument_id, instrument_no, student_id], (err, usageResult) => {
                if (err) {
                  return db.rollback(() => {
                    console.error('Error inserting into instrument_usage:', err);
                    res.status(500).json({ message: 'Internal server error' });
                  });
                }

                db.commit(err => {
                  if (err) {
                    return db.rollback(() => {
                      console.error('Error committing transaction:', err);
                      res.status(500).json({ message: 'Internal server error' });
                    });
                  }

                  res.status(200).json({ message: 'Instrument borrowed successfully.', booking_id: bookingResult.insertId });
                });
              });
            });
          });
        });
      });
    });
  });
});

router.get('/api/inventory', (req, res) => {
  const query = `
    SELECT
        i.instrument_id,
        i.instrument_no,
        i.instrument_type,
        i.status,
        i.barcode,
        i.brand,
        i.description,
        i.image_url,
        s.first_name,
        s.last_name,
        s.year,
        s.sec,
        ib.booking_date,
        ib.time_in,
        s.rfid_uid,
        'instrument' as item_category
    FROM
        instrument_info i
    LEFT JOIN
        instrument_bookings ib ON i.instrument_id = ib.instrument_id AND ib.status = 'Active'
    LEFT JOIN
        student s ON ib.student_id = s.student_id
    UNION ALL
    SELECT
        t.tool_id as instrument_id,
        t.tool_no as instrument_no,
        t.tool_type as instrument_type,
        t.status,
        t.barcode,
        t.brand,
        t.description,
        t.image_url,
        NULL as first_name,
        NULL as last_name,
        NULL as year,
        NULL as sec,
        NULL as booking_date,
        NULL as time_in,
        NULL as rfid_uid,
        'tool' as item_category
    FROM
        tools_info t
    ORDER BY CASE WHEN status = 'Borrowed' THEN 0 ELSE 1 END, item_category, instrument_type, instrument_no;
  `;

  db.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching inventory:', err);
      res.status(500).json({ message: 'Internal server error' });
    } else {
      res.json(results);
    }
  });
});

router.get('/api/available-instruments', (req, res) => {
  const sql = 'SELECT instrument_id, instrument_type, instrument_no FROM instrument_info WHERE status = "Available"';
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error fetching available instruments:', err);
      return res.status(500).json({ message: 'Internal server error.' });
    }

    const availableInstruments = {
      Guitar: [],
      Piano: [],
      Violin: [],
    };

    results.forEach((instrument) => {
      if (availableInstruments[instrument.instrument_type]) {
        availableInstruments[instrument.instrument_type].push(instrument);
      }
    });
    res.status(200).json(availableInstruments);
  });
});

router.post('/api/timeout-instrument', (req, res) => {
  const { instrument_id } = req.body;
  const time_out = new Date();

  db.beginTransaction(err => {
    if (err) {
      console.error('Error starting transaction:', err);
      return res.status(500).json({ message: 'Internal server error.' });
    }

    // 1. Get the booking start time and student_id
    const getBookingSql = 'SELECT time_in, student_id FROM instrument_bookings WHERE instrument_id = ? AND status = "Active" ';
    db.query(getBookingSql, [instrument_id], (err, results) => {
      if (err) {
        return db.rollback(() => {
          console.error('Error fetching booking:', err);
          res.status(500).json({ message: 'Internal server error during booking fetch.' });
        });
      }

      if (results.length === 0) {
        return db.rollback(() => {
          res.status(404).json({ message: 'Active booking not found for this instrument.' });
        });
      }

      const time_in = results[0].time_in;
      const student_id = results[0].student_id;
      const duration = Math.round((time_out.getTime() - new Date(time_in).getTime()) / 60000); // in minutes

      const proceedWithTimeoutUpdates = () => {
        // 2. Update instrument_usage: set end_time for the active booking
        const updateUsageSql = 'UPDATE instrument_usage SET end_time = ? WHERE instrument_id = ? AND student_id = ? AND end_time IS NULL';
        db.query(updateUsageSql, [time_out.toISOString(), instrument_id, student_id], (err, usageResult) => {
          if (err) {
            return db.rollback(() => {
              console.error('Error updating instrument_usage:', err);
              res.status(500).json({ message: 'Internal server error during usage update.' });
            });
          }

          // 3. Delete from instrument_bookings
          const deleteBookingSql = 'DELETE FROM instrument_bookings WHERE instrument_id = ? AND status = "Active"';
          db.query(deleteBookingSql, [instrument_id], (err, deleteResult) => {
            if (err) {
              return db.rollback(() => {
                console.error('Error deleting from instrument_bookings:', err);
                res.status(500).json({ message: 'Internal server error during booking deletion.' });
              });
            }

            // 4. Update instrument_info: set status to 'Available'
            const updateInfoSql = 'UPDATE instrument_info SET status = ? WHERE instrument_id = ?';
            db.query(updateInfoSql, ['Available', instrument_id], (err, infoResult) => {
              if (err) {
                return db.rollback(() => {
                  console.error('Error updating instrument_info:', err);
                  res.status(500).json({ message: 'Internal server error during info update.' });
                });
              }

              db.commit(err => {
                if (err) {
                  return db.rollback(() => {
                    console.error('Error committing transaction:', err);
                    res.status(500).json({ message: 'Internal server error during transaction commit.' });
                  });
                }
                res.status(200).json({ message: 'Instrument successfully timed out.' });
              });
            });
          });
        });
      };
      proceedWithTimeoutUpdates(); // No MTL time deduction for instruments
    });
  });
});

router.put('/api/instruments/:instrument_id/status', (req, res) => {
  const { instrument_id } = req.params;
  const { status } = req.body;

  if (!status) {
    return res.status(400).json({ message: 'Status is required.' });
  }

  const sql = 'UPDATE instrument_info SET status = ? WHERE instrument_id = ?';
  db.query(sql, [status, instrument_id], (err, result) => {
    if (err) {
      console.error('Error updating instrument status:', err);
      return res.status(500).json({ message: 'Internal server error' });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Instrument not found.' });
    }
    res.status(200).json({ message: 'Instrument status updated successfully.' });
  });
});

router.put('/api/instruments/:instrument_id', upload.single('image'), (req, res) => {
  const { instrument_id } = req.params;
  const { instrument_no, instrument_type, brand, barcode, description, status } = req.body;
  let imageUrl = req.body.image_url; // Keep existing image if not updated

  if (req.file) {
    imageUrl = `/uploads/${req.file.filename}`;
  }

  const sql = 'UPDATE instrument_info SET instrument_no = ?, instrument_type = ?, brand = ?, barcode = ?, description = ?, status = ?, image_url = ? WHERE instrument_id = ?';
  const values = [instrument_no, instrument_type, brand, barcode, description, status, imageUrl, instrument_id];

  db.query(sql, values, (err, result) => {
    if (err) {
      console.error('Error updating instrument:', err);
      return res.status(500).json({ message: 'Internal server error' });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Instrument not found.' });
    }
    res.status(200).json({ message: 'Instrument updated successfully.' });
  });
});

router.delete('/api/instruments/:instrument_id', (req, res) => {
  const { instrument_id } = req.params;

  const sql = 'DELETE FROM instrument_info WHERE instrument_id = ?';
  db.query(sql, [instrument_id], (err, result) => {
    if (err) {
      console.error('Error deleting instrument:', err);
      return res.status(500).json({ message: 'Internal server error' });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Instrument not found.' });
    }
    res.status(200).json({ message: 'Instrument deleted successfully.' });
  });
});

router.post('/api/instruments', (req, res) => {
  console.log("Received request to add instrument:", req.body);
  upload.single('image')(req, res, function (err) {
    if (err instanceof multer.MulterError) {
      // A Multer error occurred when uploading.
      return res.status(500).json({ message: err.message });
    } else if (err) {
      // An unknown error occurred when uploading.
      return res.status(500).json({ message: `An unknown error occurred: ${err.message}` });
    }

    // Everything went fine.
    const { instrument_no, instrument_type, barcode, brand, description } = req.body;
    const imageUrl = req.file ? `/uploads/${req.file.filename}` : null;

    if (!instrument_no || !instrument_type) {
      return res.status(400).json({ message: 'Instrument number and type are required.' });
    }

    const sql = 'INSERT INTO instrument_info (instrument_no, instrument_type, barcode, brand, description, image_url, status) VALUES (?, ?, ?, ?, ?, ?, ?)';
    const values = [instrument_no, instrument_type, barcode, brand, description, imageUrl, 'Available'];

    db.query(sql, values, (err, result) => {
      if (err) {
        console.error('Error adding instrument:', err);
        return res.status(500).json({ message: 'Internal server error' });
      }
      console.log("Instrument added successfully:", result);
      res.status(201).json({ message: 'Instrument added successfully.', instrument_id: result.insertId });
    });
  })
});

export default router;
